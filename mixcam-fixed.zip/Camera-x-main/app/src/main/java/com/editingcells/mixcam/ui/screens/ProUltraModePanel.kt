package com.editingcells.mixcam.ui.screens

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.data.local.ProUltraPreset
import com.editingcells.mixcam.ui.components.GlassButton
import com.editingcells.mixcam.ui.components.GlassCard
import com.editingcells.mixcam.ui.components.GlassPanel
import com.editingcells.mixcam.ui.components.GlassSlider
import com.editingcells.mixcam.viewmodel.ProUltraState

@Composable
fun ProUltraModePanel(
    proState: ProUltraState,
    savedPresets: List<ProUltraPreset>,
    onIsoChange: (Int) -> Unit,
    onShutterChange: (Long) -> Unit,
    onWbChange: (Int) -> Unit,
    onEvChange: (Int) -> Unit,
    onFocusChange: (Float) -> Unit,
    onRgbChange: (Float, Float, Float) -> Unit,
    onToggleRaw: () -> Unit,
    onSetBracketing: (Int) -> Unit,
    onSavePreset: (String) -> Unit,
    onLoadPreset: (ProUltraPreset) -> Unit,
    liquidGlass: Boolean = true,
    modifier: Modifier = Modifier
) {
    var showSaveDialog by remember { mutableStateOf(false) }
    var presetNameInput by remember { mutableStateOf("") }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Pro Ultra Preset") },
            text = {
                OutlinedTextField(
                    value = presetNameInput,
                    onValueChange = { presetNameInput = it },
                    label = { Text("Preset Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                GlassButton(
                    onClick = {
                        if (presetNameInput.isNotBlank()) {
                            onSavePreset(presetNameInput.trim())
                            presetNameInput = ""
                            showSaveDialog = false
                        }
                    },
                    liquidGlass = liquidGlass
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                GlassButton(onClick = { showSaveDialog = false }, liquidGlass = liquidGlass) {
                    Text("Cancel")
                }
            }
        )
    }

    GlassPanel(
        modifier = modifier.fillMaxWidth(),
        liquidGlass = liquidGlass
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "PRO ULTRA ADVANCED STUDIO",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlassButton(
                        onClick = {
                            // Reset to auto defaults
                            onIsoChange(400)
                            onShutterChange(10_000_000L) // 1/100s
                            onEvChange(0)
                        },
                        liquidGlass = liquidGlass
                    ) {
                        Text("Auto Exposure", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    GlassButton(
                        onClick = { showSaveDialog = true },
                        liquidGlass = liquidGlass
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = "Save Preset", tint = Color.White)
                            Text("Save", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            // Saved Pro Ultra Presets Strip
            if (savedPresets.isNotEmpty()) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(savedPresets) { preset ->
                        GlassCard(
                            onClick = { onLoadPreset(preset) },
                            liquidGlass = liquidGlass
                        ) {
                            Text(
                                text = preset.name,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Include Standard Pro Controls
            ProModePanel(
                proState = proState,
                onIsoChange = onIsoChange,
                onShutterChange = onShutterChange,
                onWbChange = onWbChange,
                onEvChange = onEvChange,
                onFocusChange = onFocusChange,
                liquidGlass = liquidGlass,
                wrapInPanel = false
            )

            // Per-Channel RGB Color Adjustments
            Text(
                text = "RGB COLOR GAIN TUNER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (liquidGlass) Color.White.copy(alpha = 0.8f) else Color.Black
            )

            GlassSlider(
                label = "Red Gain",
                value = proState.redGain,
                onValueChange = { onRgbChange(it, proState.greenGain, proState.blueGain) },
                valueRange = 0.5f..2.0f,
                formattedValue = "R ${(proState.redGain * 100).toInt()}%",
                liquidGlass = liquidGlass
            )

            GlassSlider(
                label = "Green Gain",
                value = proState.greenGain,
                onValueChange = { onRgbChange(proState.redGain, it, proState.blueGain) },
                valueRange = 0.5f..2.0f,
                formattedValue = "G ${(proState.greenGain * 100).toInt()}%",
                liquidGlass = liquidGlass
            )

            GlassSlider(
                label = "Blue Gain",
                value = proState.blueGain,
                onValueChange = { onRgbChange(proState.redGain, proState.greenGain, it) },
                valueRange = 0.5f..2.0f,
                formattedValue = "B ${(proState.blueGain * 100).toInt()}%",
                liquidGlass = liquidGlass
            )

            // RAW & Bracketing Toggles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                GlassButton(
                    onClick = onToggleRaw,
                    liquidGlass = liquidGlass
                ) {
                    Text(
                        text = if (proState.rawEnabled) "RAW Capture: ON" else "RAW Capture: OFF",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (proState.rawEnabled) MaterialTheme.colorScheme.primary else Color.White
                    )
                }

                GlassButton(
                    onClick = {
                        val next = when (proState.bracketingSteps) {
                            0 -> 3
                            3 -> 5
                            else -> 0
                        }
                        onSetBracketing(next)
                    },
                    liquidGlass = liquidGlass
                ) {
                    Text(
                        text = if (proState.bracketingSteps > 0) "${proState.bracketingSteps}-Frame EV Bracket" else "Bracketing: OFF",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (proState.bracketingSteps > 0) MaterialTheme.colorScheme.primary else Color.White
                    )
                }
            }
        }
    }
}
