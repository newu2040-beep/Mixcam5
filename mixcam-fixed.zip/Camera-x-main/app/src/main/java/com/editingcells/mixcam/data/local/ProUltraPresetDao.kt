package com.editingcells.mixcam.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProUltraPresetDao {
    @Query("SELECT * FROM pro_ultra_presets ORDER BY timestamp DESC")
    fun getAllPresets(): Flow<List<ProUltraPreset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreset(preset: ProUltraPreset): Long

    @Delete
    suspend fun deletePreset(preset: ProUltraPreset)

    @Query("SELECT * FROM pro_ultra_presets WHERE id = :id")
    suspend fun getPresetById(id: Long): ProUltraPreset?
}
