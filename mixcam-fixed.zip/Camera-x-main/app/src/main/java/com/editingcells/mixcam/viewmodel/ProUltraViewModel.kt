package com.editingcells.mixcam.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.editingcells.mixcam.data.local.ProUltraPreset
import com.editingcells.mixcam.domain.ProUltraConfigRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ProUltraState(
    val iso: Int = 400,                          // 100 to 3200
    val shutterSpeedNs: Long = 10_000_000L,      // 125_000L (1/8000s) to 1_000_000_000L (1s)
    val whiteBalanceKelvin: Int = 5500,          // 2000 to 10000
    val exposureComp: Int = 0,                   // -3 to +3
    val focusDistance: Float = 0f,               // 0f (infinity) to 1f (macro)
    val contrastCurve: String = "0,0;0.5,0.5;1,1",
    val redGain: Float = 1.0f,                   // 0.5f to 2.0f
    val greenGain: Float = 1.0f,                 // 0.5f to 2.0f
    val blueGain: Float = 1.0f,                  // 0.5f to 2.0f
    val rawEnabled: Boolean = false,
    val bracketingSteps: Int = 0,               // 0, 3, 5 steps
    val nightStackingDurationSec: Int = 3        // 2s, 5s, 10s for Night Mode
)

class ProUltraViewModel(
    private val repository: ProUltraConfigRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ProUltraState())
    val state: StateFlow<ProUltraState> = _state.asStateFlow()

    val savedPresets: StateFlow<List<ProUltraPreset>> = repository.allPresets
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun updateIso(iso: Int) {
        _state.value = _state.value.copy(iso = iso)
    }

    fun updateShutterSpeedNs(ns: Long) {
        _state.value = _state.value.copy(shutterSpeedNs = ns)
    }

    fun updateWhiteBalance(kelvin: Int) {
        _state.value = _state.value.copy(whiteBalanceKelvin = kelvin)
    }

    fun updateExposureComp(comp: Int) {
        _state.value = _state.value.copy(exposureComp = comp)
    }

    fun updateFocusDistance(distance: Float) {
        _state.value = _state.value.copy(focusDistance = distance)
    }

    fun updateRgbGains(red: Float, green: Float, blue: Float) {
        _state.value = _state.value.copy(redGain = red, greenGain = green, blueGain = blue)
    }

    fun toggleRaw() {
        _state.value = _state.value.copy(rawEnabled = !_state.value.rawEnabled)
    }

    fun setBracketingSteps(steps: Int) {
        _state.value = _state.value.copy(bracketingSteps = steps)
    }

    fun setNightDuration(sec: Int) {
        _state.value = _state.value.copy(nightStackingDurationSec = sec)
    }

    fun saveCurrentAsPreset(name: String) {
        viewModelScope.launch {
            val s = _state.value
            repository.savePreset(
                name = name,
                iso = s.iso,
                shutterSpeedNs = s.shutterSpeedNs,
                whiteBalanceKelvin = s.whiteBalanceKelvin,
                exposureComp = s.exposureComp,
                focusDistance = s.focusDistance,
                contrastCurve = s.contrastCurve,
                redGain = s.redGain,
                greenGain = s.greenGain,
                blueGain = s.blueGain,
                rawEnabled = s.rawEnabled,
                bracketingSteps = s.bracketingSteps
            )
        }
    }

    fun loadPreset(preset: ProUltraPreset) {
        _state.value = _state.value.copy(
            iso = preset.iso,
            shutterSpeedNs = preset.shutterSpeedNs,
            whiteBalanceKelvin = preset.whiteBalanceKelvin,
            exposureComp = preset.exposureComp,
            focusDistance = preset.focusDistance,
            contrastCurve = preset.contrastCurve,
            redGain = preset.redGain,
            greenGain = preset.greenGain,
            blueGain = preset.blueGain,
            rawEnabled = preset.rawEnabled,
            bracketingSteps = preset.bracketingSteps
        )
    }

    fun deletePreset(preset: ProUltraPreset) {
        viewModelScope.launch {
            repository.deletePreset(preset)
        }
    }

    class Factory(private val repository: ProUltraConfigRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ProUltraViewModel(repository) as T
        }
    }
}
