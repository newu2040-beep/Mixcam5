package com.editingcells.mixcam.ui.theme

import androidx.compose.ui.graphics.Color

// Liquid Glass Palette (Dark Translucent Canvas + Glowing Accents)
val GlassDarkCanvas = Color(0xFF0B0F19)
val GlassSurfaceDark = Color(0x331E293B)
val GlassBorderDark = Color(0x6694A3B8)
val GlassHighlightDark = Color(0x80FFFFFF)

val GlassCyanPrimary = Color(0xFF00E5FF)
val GlassCyanSecondary = Color(0xFF00B0FF)
val GlassMagentaAccent = Color(0xFFFF007A)
val GlassGoldAccent = Color(0xFFFFD700)

// Normal Aesthetic Palette (Clean Material 3 Pastel Style)
val PastelSurface = Color(0xFFF8FAFC)
val PastelCard = Color(0xFFFFFFFF)
val PastelPrimary = Color(0xFF6366F1)
val PastelSecondary = Color(0xFF10B981)
val PastelTextPrimary = Color(0xFF1E293B)
val PastelTextSecondary = Color(0xFF64748B)

// Accent Color Presets
val AccentPresets = listOf(
    Color(0xFF00E5FF), // Electric Cyan
    Color(0xFFFF007A), // Cyber Pink
    Color(0xFF10B981), // Neon Emerald
    Color(0xFFFFB800), // Amber Gold
    Color(0xFF8B5CF6)  // Ultra Violet
)
