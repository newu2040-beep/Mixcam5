package com.editingcells.mixcam.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    liquidGlass: Boolean = true,
    shape: Shape = RoundedCornerShape(24.dp),
    blurRadius: Dp = 20.dp,
    content: @Composable BoxScope.() -> Unit
) {
    if (liquidGlass) {
        val glassBackground = Brush.linearGradient(
            colors = listOf(
                Color(0xCC0B0F19),
                Color(0x991E293B)
            )
        )
        val glassBorder = Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.25f),
                Color.White.copy(alpha = 0.08f)
            )
        )

        Box(
            modifier = modifier
                .clip(shape)
                .background(glassBackground, shape)
                .border(1.dp, glassBorder, shape),
            content = content
        )
    } else {
        Box(
            modifier = modifier
                .clip(shape)
                .background(Color.White.copy(alpha = 0.95f), shape)
                .border(1.dp, Color(0xFFE2E8F0), shape),
            content = content
        )
    }
}
