package com.editingcells.mixcam.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.editingcells.mixcam.ui.theme.SpringSpec

@Composable
fun GlassShutterButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    liquidGlass: Boolean = true,
    size: Dp = 84.dp
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.88f else 1.0f,
        animationSpec = SpringSpec,
        label = "shutter_scale"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "shutter_sheen")
    val sheenProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sheen_anim"
    )

    Box(
        modifier = modifier
            .size(size)
            .scale(scale)
            .clip(CircleShape)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (liquidGlass) {
            val outerGradient = Brush.sweepGradient(
                listOf(
                    MaterialTheme.colorScheme.primary,
                    Color.White.copy(alpha = 0.8f),
                    MaterialTheme.colorScheme.tertiary,
                    MaterialTheme.colorScheme.primary
                )
            )
            val innerGradient = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.4f),
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    Color.Transparent
                )
            )

            Box(
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(outerGradient)
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(size - 8.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f))
                        .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                        .background(innerGradient)
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(size - 12.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                )
            }
        }
    }
}

@Composable
fun GlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    liquidGlass: Boolean = true,
    shape: Shape = RoundedCornerShape(16.dp),
    content: @Composable () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = SpringSpec,
        label = "button_scale"
    )

    Box(
        modifier = modifier
            .scale(scale)
            .clip(shape)
            .clickable(interactionSource = interactionSource, indication = null) { onClick() }
            .then(
                if (liquidGlass) {
                    Modifier
                        .background(Color.White.copy(alpha = 0.12f), shape)
                        .border(1.dp, Color.White.copy(alpha = 0.3f), shape)
                } else {
                    Modifier
                        .background(MaterialTheme.colorScheme.primaryContainer, shape)
                        .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), shape)
                }
            )
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
