package com.editingcells.mixcam.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.ui.components.GlassBottomSheet
import com.editingcells.mixcam.ui.components.GlassButton

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RatioPickerSheet(
    selectedRatio: String,
    onRatioSelected: (String) -> Unit,
    onDismiss: () -> Unit,
    liquidGlass: Boolean = true
) {
    val ratios = listOf("4:3", "16:9", "1:1", "21:9", "FULL")

    GlassBottomSheet(
        onDismissRequest = onDismiss,
        liquidGlass = liquidGlass
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "ASPECT RATIO",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ratios.forEach { ratio ->
                    val isSelected = ratio == selectedRatio
                    GlassButton(
                        onClick = {
                            onRatioSelected(ratio)
                            onDismiss()
                        },
                        liquidGlass = liquidGlass,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = ratio,
                                fontSize = 16.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White
                            )
                            if (isSelected) {
                                Text(
                                    text = "SELECTED ✓",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
