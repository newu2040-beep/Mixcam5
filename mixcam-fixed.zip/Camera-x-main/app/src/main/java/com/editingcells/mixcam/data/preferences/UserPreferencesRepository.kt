package com.editingcells.mixcam.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val GRID_ENABLED = booleanPreferencesKey("grid_enabled")
        val SELECTED_MP = stringPreferencesKey("selected_mp")
        val SELECTED_RATIO = stringPreferencesKey("selected_ratio")
        val ACCENT_COLOR_INDEX = intPreferencesKey("accent_color_index")
        val SHUTTER_SOUND_INDEX = intPreferencesKey("shutter_sound_index")
        val ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
    }

    val isLiquidGlassMode: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.THEME_MODE] ?: "LIQUID_GLASS" == "LIQUID_GLASS"
    }

    val themeModeName: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.THEME_MODE] ?: "LIQUID_GLASS"
    }

    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.NOTIFICATIONS_ENABLED] ?: true
    }

    val gridEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.GRID_ENABLED] ?: false
    }

    val selectedMp: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.SELECTED_MP] ?: "12MP"
    }

    val selectedRatio: Flow<String> = context.dataStore.data.map { prefs ->
        prefs[Keys.SELECTED_RATIO] ?: "4:3"
    }

    val accentColorIndex: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.ACCENT_COLOR_INDEX] ?: 0
    }

    val shutterSoundIndex: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[Keys.SHUTTER_SOUND_INDEX] ?: 0
    }

    val onboardingCompleted: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[Keys.ONBOARDING_COMPLETED] ?: false
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.THEME_MODE] = mode
        }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.NOTIFICATIONS_ENABLED] = enabled
        }
    }

    suspend fun setGridEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.GRID_ENABLED] = enabled
        }
    }

    suspend fun setSelectedMp(mp: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_MP] = mp
        }
    }

    suspend fun setSelectedRatio(ratio: String) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SELECTED_RATIO] = ratio
        }
    }

    suspend fun setAccentColorIndex(index: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACCENT_COLOR_INDEX] = index
        }
    }

    suspend fun setShutterSoundIndex(index: Int) {
        context.dataStore.edit { prefs ->
            prefs[Keys.SHUTTER_SOUND_INDEX] = index
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ONBOARDING_COMPLETED] = completed
        }
    }
}
