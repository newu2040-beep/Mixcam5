package com.editingcells.mixcam.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.util.Size
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.CameraFront
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.editingcells.mixcam.data.local.ProUltraPreset
import com.editingcells.mixcam.domain.CameraMode
import com.editingcells.mixcam.domain.FilterEngine
import com.editingcells.mixcam.domain.FilterSpec
import com.editingcells.mixcam.domain.FlashMode
import com.editingcells.mixcam.ui.components.GlassButton
import com.editingcells.mixcam.ui.components.GlassCard
import com.editingcells.mixcam.ui.components.GlassIconButton
import com.editingcells.mixcam.ui.components.GlassPanel
import com.editingcells.mixcam.ui.components.GlassSegmentedControl
import com.editingcells.mixcam.ui.components.GlassShutterButton
import com.editingcells.mixcam.viewmodel.CameraViewModel
import com.editingcells.mixcam.viewmodel.ProUltraViewModel

@Composable
fun CameraScreen(
    cameraViewModel: CameraViewModel,
    proUltraViewModel: ProUltraViewModel,
    filterViewModel: com.editingcells.mixcam.viewmodel.FilterViewModel,
    onOpenMenu: () -> Unit,
    onOpenRatioPicker: () -> Unit,
    onOpenFilterGallery: () -> Unit,
    liquidGlass: Boolean = true
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    val cameraState by cameraViewModel.uiState.collectAsState()
    val proState by proUltraViewModel.state.collectAsState()
    val savedProUltraPresets by proUltraViewModel.savedPresets.collectAsState()

    var previewView by remember { mutableStateOf<PreviewView?>(null) }

    val isManualMode = cameraState.cameraMode == CameraMode.PRO || cameraState.cameraMode == CameraMode.PRO_ULTRA

    // STRUCTURAL rebind: only re-binds the whole camera use-case graph (which causes a
    // brief preview flash) when something that actually requires a rebind changes —
    // front/back camera, output resolution, or entering/leaving a manual-controls mode.
    //
    // BUGFIX: this used to also depend on proState.iso / shutterSpeedNs / whiteBalanceKelvin /
    // exposureComp / focusDistance, so it re-ran (and unbound + rebound the entire camera)
    // on every single tick of every Pro/Pro Ultra slider — visibly flashing/stuttering the
    // preview while dragging. Live slider values are now pushed separately below via
    // updateManualControls(), which patches the running capture request instead of
    // rebinding anything.
    LaunchedEffect(
        cameraState.isFrontFacing,
        cameraState.selectedMp,
        isManualMode,
        previewView
    ) {
        val pv = previewView ?: return@LaunchedEffect
        val targetSize = cameraState.supportedMps.firstOrNull { it.label == cameraState.selectedMp }?.size

        cameraViewModel.cameraController.bindCamera(
            lifecycleOwner = lifecycleOwner,
            surfaceProvider = pv.surfaceProvider,
            isFront = cameraState.isFrontFacing,
            manualControlsEnabled = isManualMode,
            targetResolution = targetSize
        )

        // Re-apply whatever manual values are currently set immediately after a
        // structural rebind (e.g. after switching front/back camera mid Pro session).
        if (isManualMode) {
            cameraViewModel.cameraController.updateManualControls(
                iso = proState.iso,
                shutterSpeedNs = proState.shutterSpeedNs,
                whiteBalanceKelvin = proState.whiteBalanceKelvin,
                exposureComp = proState.exposureComp,
                focusDistance = proState.focusDistance
            )
        }
    }

    // LIVE control updates: lightweight capture-request patches, no rebind, no flash.
    LaunchedEffect(
        proState.iso,
        proState.shutterSpeedNs,
        proState.whiteBalanceKelvin,
        proState.exposureComp,
        proState.focusDistance,
        isManualMode
    ) {
        if (!isManualMode) return@LaunchedEffect
        cameraViewModel.cameraController.updateManualControls(
            iso = proState.iso,
            shutterSpeedNs = proState.shutterSpeedNs,
            whiteBalanceKelvin = proState.whiteBalanceKelvin,
            exposureComp = proState.exposureComp,
            focusDistance = proState.focusDistance
        )
    }

    val aspectRatioFloat = when (cameraState.selectedRatio) {
        "1:1" -> 1.0f
        "16:9" -> 16f / 9f
        "21:9" -> 21f / 9f
        "FULL" -> 2.1f
        else -> 4f / 3f
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Live Camera Viewfinder
        Box(
            modifier = Modifier
                .fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    PreviewView(ctx).also {
                        it.scaleType = PreviewView.ScaleType.FILL_CENTER
                        previewView = it
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f / aspectRatioFloat)
            )

            // Grid Overlay if enabled
            if (cameraState.isGridVisible) {
                GridOverlay()
            }
        }

        // TOP CONTROLS BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 16.dp, end = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassIconButton(
                icon = Icons.Default.Menu,
                contentDescription = "Menu Drawer",
                onClick = onOpenMenu,
                liquidGlass = liquidGlass
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Flash Cycle Button
                val flashIcon = when (cameraState.flashMode) {
                    FlashMode.OFF -> Icons.Default.FlashOff
                    FlashMode.ON -> Icons.Default.FlashOn
                    FlashMode.AUTO -> Icons.Default.FlashAuto
                    FlashMode.TORCH -> Icons.Default.FlashOn
                }
                GlassIconButton(
                    icon = flashIcon,
                    contentDescription = "Flash Mode",
                    onClick = { cameraViewModel.cycleFlashMode() },
                    liquidGlass = liquidGlass,
                    tint = if (cameraState.flashMode != FlashMode.OFF) MaterialTheme.colorScheme.primary else Color.White
                )

                // Grid Toggle Button
                GlassIconButton(
                    icon = Icons.Default.GridOn,
                    contentDescription = "Toggle Grid",
                    onClick = { cameraViewModel.toggleGrid() },
                    liquidGlass = liquidGlass,
                    tint = if (cameraState.isGridVisible) MaterialTheme.colorScheme.primary else Color.White
                )

                // Megapixel Switcher Chip
                val mpSupportedList = cameraState.supportedMps.filter { it.isSupported }
                if (mpSupportedList.isNotEmpty()) {
                    GlassButton(
                        onClick = {
                            val currentIndex = mpSupportedList.indexOfFirst { it.label == cameraState.selectedMp }
                            val nextIndex = if (currentIndex < 0 || currentIndex == mpSupportedList.size - 1) 0 else currentIndex + 1
                            cameraViewModel.setSelectedMp(mpSupportedList[nextIndex].label)
                        },
                        liquidGlass = liquidGlass
                    ) {
                        Text(
                            text = cameraState.selectedMp,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Front / Back Camera Switch Button
                GlassIconButton(
                    icon = Icons.Default.CameraFront,
                    contentDescription = "Switch Camera",
                    onClick = { cameraViewModel.toggleCameraFacing() },
                    liquidGlass = liquidGlass
                )

                // Gallery Full Access Button
                GlassIconButton(
                    icon = Icons.Default.PhotoLibrary,
                    contentDescription = "Open Media Gallery",
                    onClick = {
                        try {
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                                type = "image/*"
                                flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            try {
                                val galleryIntent = android.content.Intent(android.content.Intent.ACTION_MAIN).apply {
                                    addCategory(android.content.Intent.CATEGORY_APP_GALLERY)
                                    flags = android.content.Intent.FLAG_ACTIVITY_NEW_TASK
                                }
                                context.startActivity(galleryIntent)
                            } catch (_: Exception) {}
                        }
                    },
                    liquidGlass = liquidGlass,
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }

        // MIDDLE: EXPANDABLE MODE MANUAL CONTROL PANELS
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 220.dp, start = 16.dp, end = 16.dp)
        ) {
            AnimatedVisibility(
                visible = cameraState.cameraMode == CameraMode.PRO,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it }
            ) {
                ProModePanel(
                    proState = proState,
                    onIsoChange = { proUltraViewModel.updateIso(it) },
                    onShutterChange = { proUltraViewModel.updateShutterSpeedNs(it) },
                    onWbChange = { proUltraViewModel.updateWhiteBalance(it) },
                    onEvChange = { proUltraViewModel.updateExposureComp(it) },
                    onFocusChange = { proUltraViewModel.updateFocusDistance(it) },
                    liquidGlass = liquidGlass
                )
            }

            AnimatedVisibility(
                visible = cameraState.cameraMode == CameraMode.PRO_ULTRA,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it }
            ) {
                ProUltraModePanel(
                    proState = proState,
                    savedPresets = savedProUltraPresets,
                    onIsoChange = { proUltraViewModel.updateIso(it) },
                    onShutterChange = { proUltraViewModel.updateShutterSpeedNs(it) },
                    onWbChange = { proUltraViewModel.updateWhiteBalance(it) },
                    onEvChange = { proUltraViewModel.updateExposureComp(it) },
                    onFocusChange = { proUltraViewModel.updateFocusDistance(it) },
                    onRgbChange = { r, g, b -> proUltraViewModel.updateRgbGains(r, g, b) },
                    onToggleRaw = { proUltraViewModel.toggleRaw() },
                    onSetBracketing = { proUltraViewModel.setBracketingSteps(it) },
                    onSavePreset = { proUltraViewModel.saveCurrentAsPreset(it) },
                    onLoadPreset = { proUltraViewModel.loadPreset(it) },
                    liquidGlass = liquidGlass
                )
            }

            AnimatedVisibility(
                visible = cameraState.cameraMode == CameraMode.NIGHT,
                enter = fadeIn() + slideInVertically { it },
                exit = fadeOut() + slideOutVertically { it }
            ) {
                NightModePanel(
                    selectedDurationSec = proState.nightStackingDurationSec,
                    onDurationSelected = { proUltraViewModel.setNightDuration(it) },
                    liquidGlass = liquidGlass
                )
            }
        }

        // BOTTOM GLASS CONTROL CONSOLE
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp, start = 12.dp, end = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Mode Switcher Segmented Bar
            GlassSegmentedControl(
                selectedMode = cameraState.cameraMode,
                onModeSelected = { cameraViewModel.setCameraMode(it) },
                liquidGlass = liquidGlass
            )

            val customPresets by filterViewModel.customPresets.collectAsState()
            
            // Bottom Filter Carousel Strip
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Built-in
                items(FilterEngine.BUILT_IN_FILTERS) { filter ->
                    val isSelected = filter.id == cameraState.activeFilter.id
                    GlassCard(
                        onClick = { cameraViewModel.setActiveFilter(filter) },
                        isSelected = isSelected,
                        liquidGlass = liquidGlass
                    ) {
                        Text(
                            text = filter.name,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                
                // Custom
                items(customPresets) { preset ->
                    val customSpec = FilterSpec(
                        id = "custom_${preset.id}",
                        name = preset.name,
                        category = "Custom Preset",
                        brightness = preset.brightness,
                        contrast = preset.contrast,
                        saturation = preset.saturation,
                        sepia = preset.sepia,
                        warmth = preset.warmth,
                        tint = preset.tint,
                        vignette = preset.vignette,
                        sharpen = preset.sharpen
                    )
                    val isSelected = customSpec.id == cameraState.activeFilter.id
                    
                    GlassCard(
                        onClick = { cameraViewModel.setActiveFilter(customSpec) },
                        isSelected = isSelected,
                        liquidGlass = liquidGlass
                    ) {
                        Text(
                            text = customSpec.name,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // PRIMARY SHUTTER CONSOLE ROW
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Ratio Picker Trigger
                GlassButton(
                    onClick = onOpenRatioPicker,
                    liquidGlass = liquidGlass
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AspectRatio, contentDescription = "Aspect Ratio", tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(cameraState.selectedRatio, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                // GLASS SHUTTER BUTTON (CENTRAL THUMB ZONE)
                Box(contentAlignment = Alignment.Center) {
                    GlassShutterButton(
                        onClick = { cameraViewModel.capturePhoto() },
                        liquidGlass = liquidGlass
                    )
                    if (cameraState.isCapturing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(92.dp),
                            color = MaterialTheme.colorScheme.primary,
                            strokeWidth = 3.dp
                        )
                    }
                }

                // Filter Gallery Trigger
                GlassButton(
                    onClick = onOpenFilterGallery,
                    liquidGlass = liquidGlass
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.PhotoFilter, contentDescription = "Filter Gallery", tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Filters", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun GridOverlay() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        val strokeColor = Color.White.copy(alpha = 0.35f)
        val strokeWidth = 1.5f

        // Vertical rule-of-thirds lines
        drawLine(
            color = strokeColor,
            start = Offset(width / 3f, 0f),
            end = Offset(width / 3f, height),
            strokeWidth = strokeWidth
        )
        drawLine(
            color = strokeColor,
            start = Offset(width * 2f / 3f, 0f),
            end = Offset(width * 2f / 3f, height),
            strokeWidth = strokeWidth
        )

        // Horizontal rule-of-thirds lines
        drawLine(
            color = strokeColor,
            start = Offset(0f, height / 3f),
            end = Offset(width, height / 3f),
            strokeWidth = strokeWidth
        )
        drawLine(
            color = strokeColor,
            start = Offset(0f, height * 2f / 3f),
            end = Offset(width, height * 2f / 3f),
            strokeWidth = strokeWidth
        )
    }
}
