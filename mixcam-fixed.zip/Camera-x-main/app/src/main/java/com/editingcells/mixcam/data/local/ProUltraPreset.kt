package com.editingcells.mixcam.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "pro_ultra_presets")
data class ProUltraPreset(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val iso: Int = 400,
    val shutterSpeedNs: Long = 10_000_000L, // 1/100s in nanoseconds
    val whiteBalanceKelvin: Int = 5500,
    val exposureComp: Int = 0,
    val focusDistance: Float = 0f,          // 0f (infinity) to 1f (macro)
    val contrastCurve: String = "0,0;0.5,0.5;1,1", // S-curve control points
    val redGain: Float = 1.0f,
    val greenGain: Float = 1.0f,
    val blueGain: Float = 1.0f,
    val rawEnabled: Boolean = false,
    val bracketingSteps: Int = 0,          // -1, 0, +1 EV bracketing count
    val timestamp: Long = System.currentTimeMillis()
)
