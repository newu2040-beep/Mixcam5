package com.editingcells.mixcam.ui.navigation

object NavRoutes {
    const val ONBOARDING = "onboarding"
    const val CAMERA = "camera"
    const val FILTER_GALLERY = "filter_gallery"
    const val PRO_ULTRA_PRESETS = "pro_ultra_presets"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
}
