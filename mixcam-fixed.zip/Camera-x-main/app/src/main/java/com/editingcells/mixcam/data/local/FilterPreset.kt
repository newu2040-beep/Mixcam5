package com.editingcells.mixcam.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "filter_presets")
data class FilterPreset(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String = "Custom",
    val brightness: Float = 0f,      // -1f to 1f
    val contrast: Float = 1f,        // 0.5f to 2f
    val saturation: Float = 1f,      // 0f to 2f
    val sepia: Float = 0f,           // 0f to 1f
    val vignette: Float = 0f,        // 0f to 1f
    val warmth: Float = 0f,          // -1f (cool) to 1f (warm)
    val tint: Float = 0f,            // -1f (green) to 1f (magenta)
    val sharpen: Float = 0f,         // 0f to 1f
    val isCustom: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
