package com.editingcells.mixcam.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.ui.components.GlassButton
import com.editingcells.mixcam.ui.components.GlassPanel
import com.editingcells.mixcam.ui.components.GlassSlider

@Composable
fun NightModePanel(
    selectedDurationSec: Int,
    onDurationSelected: (Int) -> Unit,
    liquidGlass: Boolean = true,
    modifier: Modifier = Modifier
) {
    var noiseReduction by remember { mutableFloatStateOf(0.8f) }

    GlassPanel(
        modifier = modifier.fillMaxWidth(),
        liquidGlass = liquidGlass
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "NIGHT MULTI-FRAME EXPOSURE STACKING",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 1.sp
            )

            Text(
                text = "Exposure Duration (Hold Camera Steady)",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = if (liquidGlass) Color.White.copy(alpha = 0.8f) else Color.Black
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(2, 5, 10).forEach { dur ->
                    val isSelected = dur == selectedDurationSec
                    GlassButton(
                        onClick = { onDurationSelected(dur) },
                        liquidGlass = liquidGlass,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "${dur}s Exposure",
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }
                }
            }

            GlassSlider(
                label = "Multi-Frame Noise Reduction Strength",
                value = noiseReduction,
                onValueChange = { noiseReduction = it },
                valueRange = 0f..1f,
                formattedValue = "${(noiseReduction * 100).toInt()}%",
                liquidGlass = liquidGlass
            )
        }
    }
}
