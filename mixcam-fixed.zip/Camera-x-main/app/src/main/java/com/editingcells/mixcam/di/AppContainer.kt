package com.editingcells.mixcam.di

import android.content.Context
import com.editingcells.mixcam.data.local.MixCamDatabase
import com.editingcells.mixcam.data.preferences.UserPreferencesRepository
import com.editingcells.mixcam.domain.CameraController
import com.editingcells.mixcam.domain.GallerySaveRepository
import com.editingcells.mixcam.domain.ProUltraConfigRepository

class AppContainer(private val context: Context) {

    val database: MixCamDatabase by lazy {
        MixCamDatabase.getDatabase(context)
    }

    val userPreferencesRepository: UserPreferencesRepository by lazy {
        UserPreferencesRepository(context)
    }

    val cameraController: CameraController by lazy {
        CameraController(context)
    }

    val proUltraConfigRepository: ProUltraConfigRepository by lazy {
        ProUltraConfigRepository(database.proUltraPresetDao())
    }

    val gallerySaveRepository: GallerySaveRepository by lazy {
        GallerySaveRepository(context)
    }
}
