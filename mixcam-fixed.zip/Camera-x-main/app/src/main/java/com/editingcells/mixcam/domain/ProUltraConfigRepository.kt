package com.editingcells.mixcam.domain

import com.editingcells.mixcam.data.local.ProUltraPreset
import com.editingcells.mixcam.data.local.ProUltraPresetDao
import kotlinx.coroutines.flow.Flow

class ProUltraConfigRepository(private val proUltraPresetDao: ProUltraPresetDao) {

    val allPresets: Flow<List<ProUltraPreset>> = proUltraPresetDao.getAllPresets()

    suspend fun savePreset(
        name: String,
        iso: Int,
        shutterSpeedNs: Long,
        whiteBalanceKelvin: Int,
        exposureComp: Int,
        focusDistance: Float,
        contrastCurve: String,
        redGain: Float,
        greenGain: Float,
        blueGain: Float,
        rawEnabled: Boolean,
        bracketingSteps: Int
    ): Long {
        val preset = ProUltraPreset(
            name = name,
            iso = iso,
            shutterSpeedNs = shutterSpeedNs,
            whiteBalanceKelvin = whiteBalanceKelvin,
            exposureComp = exposureComp,
            focusDistance = focusDistance,
            contrastCurve = contrastCurve,
            redGain = redGain,
            greenGain = greenGain,
            blueGain = blueGain,
            rawEnabled = rawEnabled,
            bracketingSteps = bracketingSteps
        )
        return proUltraPresetDao.insertPreset(preset)
    }

    suspend fun deletePreset(preset: ProUltraPreset) {
        proUltraPresetDao.deletePreset(preset)
    }
}
