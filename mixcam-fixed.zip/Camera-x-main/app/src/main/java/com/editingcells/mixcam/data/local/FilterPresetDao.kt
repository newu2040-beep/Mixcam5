package com.editingcells.mixcam.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface FilterPresetDao {
    @Query("SELECT * FROM filter_presets ORDER BY timestamp DESC")
    fun getAllPresets(): Flow<List<FilterPreset>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPreset(preset: FilterPreset): Long

    @Delete
    suspend fun deletePreset(preset: FilterPreset)

    @Query("SELECT * FROM filter_presets WHERE id = :id")
    suspend fun getPresetById(id: Long): FilterPreset?
}
