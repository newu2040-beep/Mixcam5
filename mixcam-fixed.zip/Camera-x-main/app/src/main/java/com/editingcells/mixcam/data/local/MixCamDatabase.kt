package com.editingcells.mixcam.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [FilterPreset::class, ProUltraPreset::class],
    version = 1,
    exportSchema = false
)
abstract class MixCamDatabase : RoomDatabase() {
    abstract fun filterPresetDao(): FilterPresetDao
    abstract fun proUltraPresetDao(): ProUltraPresetDao

    companion object {
        @Volatile
        private var INSTANCE: MixCamDatabase? = null

        fun getDatabase(context: Context): MixCamDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MixCamDatabase::class.java,
                    "mixcam_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
