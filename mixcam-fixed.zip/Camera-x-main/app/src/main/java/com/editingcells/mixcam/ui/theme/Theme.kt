package com.editingcells.mixcam.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LiquidGlassColorScheme = darkColorScheme(
    primary = GlassCyanPrimary,
    secondary = GlassCyanSecondary,
    tertiary = GlassMagentaAccent,
    background = GlassDarkCanvas,
    surface = GlassSurfaceDark,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

private val NormalAestheticColorScheme = lightColorScheme(
    primary = PastelPrimary,
    secondary = PastelSecondary,
    background = PastelSurface,
    surface = PastelCard,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onBackground = PastelTextPrimary,
    onSurface = PastelTextPrimary
)

private val CyberpunkColorScheme = darkColorScheme(
    primary = Color(0xFF00FF00), // Neon Green
    secondary = Color(0xFFFF00FF), // Magenta
    background = Color(0xFF050510),
    surface = Color(0x33200030),
    onPrimary = Color.Black,
    onBackground = Color(0xFFE0E0FF),
    onSurface = Color(0xFFE0E0FF)
)

private val RoseGoldColorScheme = lightColorScheme(
    primary = Color(0xFFE0BFB8), // Rose Gold
    secondary = Color(0xFFF3E0DC),
    background = Color(0xFFFAF3F0),
    surface = Color.White,
    onPrimary = Color.DarkGray,
    onBackground = Color(0xFF4A3B39),
    onSurface = Color(0xFF4A3B39)
)

private val MidnightBlueColorScheme = darkColorScheme(
    primary = Color(0xFF4A90E2),
    secondary = Color(0xFF003366),
    background = Color(0xFF020E1C),
    surface = Color(0xFF0A2239),
    onPrimary = Color.White,
    onBackground = Color(0xFFD0E3F3),
    onSurface = Color(0xFFD0E3F3)
)

private val VintageSepiaColorScheme = lightColorScheme(
    primary = Color(0xFF8B5A2B),
    secondary = Color(0xFFD2B48C),
    background = Color(0xFFF4ECD8),
    surface = Color(0xFFEAE0C8),
    onPrimary = Color.White,
    onBackground = Color(0xFF4A3000),
    onSurface = Color(0xFF4A3000)
)

val SpringSpec = spring<Float>(
    dampingRatio = Spring.DampingRatioMediumBouncy,
    stiffness = Spring.StiffnessLow
)

@Composable
fun MixCamTheme(
    liquidGlassMode: Boolean = true, // We will use themeName primarily
    themeName: String = "LIQUID_GLASS",
    accentColor: Color = GlassCyanPrimary,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeName) {
        "LIQUID_GLASS" -> LiquidGlassColorScheme.copy(primary = accentColor)
        "NORMAL_AESTHETIC" -> NormalAestheticColorScheme.copy(primary = accentColor)
        "CYBERPUNK" -> CyberpunkColorScheme
        "ROSE_GOLD" -> RoseGoldColorScheme
        "MIDNIGHT_BLUE" -> MidnightBlueColorScheme
        "VINTAGE_SEPIA" -> VintageSepiaColorScheme
        else -> if (liquidGlassMode) LiquidGlassColorScheme.copy(primary = accentColor) else NormalAestheticColorScheme.copy(primary = accentColor)
    }

    val isDark = when (themeName) {
        "LIQUID_GLASS", "CYBERPUNK", "MIDNIGHT_BLUE" -> true
        "NORMAL_AESTHETIC", "ROSE_GOLD", "VINTAGE_SEPIA" -> false
        else -> liquidGlassMode
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            window.navigationBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !isDark
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
