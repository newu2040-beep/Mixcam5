package com.editingcells.mixcam.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhotoFilter
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.editingcells.mixcam.ui.screens.AboutScreen
import com.editingcells.mixcam.ui.screens.CameraScreen
import com.editingcells.mixcam.ui.screens.FilterGalleryScreen
import com.editingcells.mixcam.ui.screens.OnboardingScreen
import com.editingcells.mixcam.ui.screens.ProUltraPresetsScreen
import com.editingcells.mixcam.ui.screens.RatioPickerSheet
import com.editingcells.mixcam.ui.screens.SettingsScreen
import com.editingcells.mixcam.viewmodel.CameraViewModel
import com.editingcells.mixcam.viewmodel.FilterViewModel
import com.editingcells.mixcam.viewmodel.ProUltraViewModel
import com.editingcells.mixcam.viewmodel.SettingsViewModel
import kotlinx.coroutines.launch

@Composable
fun MixCamNavGraph(
    cameraViewModel: CameraViewModel,
    proUltraViewModel: ProUltraViewModel,
    filterViewModel: FilterViewModel,
    settingsViewModel: SettingsViewModel
) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val liquidGlass by settingsViewModel.isLiquidGlassMode.collectAsState()
    val onboardingCompleted by settingsViewModel.onboardingCompleted.collectAsState()

    var showRatioPicker by remember { mutableStateOf(false) }

    val startDestination = if (onboardingCompleted) NavRoutes.CAMERA else NavRoutes.ONBOARDING

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = Color.Transparent
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .width(280.dp)
                        .background(if (liquidGlass) Color(0xF20F172A) else Color.White)
                        .padding(24.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(bottom = 24.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.CameraAlt,
                                        contentDescription = "MIXCAM Logo",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "MIXCAM",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Pro Camera Studio",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }

                            DrawerItem(
                                icon = Icons.Default.CameraAlt,
                                label = "Live Viewfinder",
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    navController.navigate(NavRoutes.CAMERA) {
                                        popUpTo(NavRoutes.CAMERA) { inclusive = true }
                                    }
                                },
                                liquidGlass = liquidGlass
                            )

                            DrawerItem(
                                icon = Icons.Default.PhotoFilter,
                                label = "Filter Gallery",
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    navController.navigate(NavRoutes.FILTER_GALLERY)
                                },
                                liquidGlass = liquidGlass
                            )

                            DrawerItem(
                                icon = Icons.Default.Tune,
                                label = "Pro Ultra Presets",
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    navController.navigate(NavRoutes.PRO_ULTRA_PRESETS)
                                },
                                liquidGlass = liquidGlass
                            )

                            DrawerItem(
                                icon = Icons.Default.Settings,
                                label = "Settings & Theme",
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    navController.navigate(NavRoutes.SETTINGS)
                                },
                                liquidGlass = liquidGlass
                            )

                            DrawerItem(
                                icon = Icons.Default.Info,
                                label = "About MIXCAM",
                                onClick = {
                                    scope.launch { drawerState.close() }
                                    navController.navigate(NavRoutes.ABOUT)
                                },
                                liquidGlass = liquidGlass
                            )
                        }

                        // Drawer Footer Credit
                        Column {
                            // Removed
                        }
                    }
                }
            }
        }
    ) {
        NavHost(
            navController = navController,
            startDestination = startDestination,
            enterTransition = { fadeIn(animationSpec = tween(220)) + slideInHorizontally { it / 5 } },
            exitTransition = { fadeOut(animationSpec = tween(220)) + slideOutHorizontally { -it / 5 } },
            popEnterTransition = { fadeIn(animationSpec = tween(220)) + slideInHorizontally { -it / 5 } },
            popExitTransition = { fadeOut(animationSpec = tween(220)) + slideOutHorizontally { it / 5 } }
        ) {
            composable(NavRoutes.ONBOARDING) {
                OnboardingScreen(
                    onOnboardingComplete = {
                        settingsViewModel.completeOnboarding()
                        navController.navigate(NavRoutes.CAMERA) {
                            popUpTo(NavRoutes.ONBOARDING) { inclusive = true }
                        }
                    },
                    liquidGlass = liquidGlass
                )
            }

            composable(NavRoutes.CAMERA) {
                val cameraState by cameraViewModel.uiState.collectAsState()

                Box(modifier = Modifier.fillMaxSize()) {
                    CameraScreen(
                        cameraViewModel = cameraViewModel,
                        proUltraViewModel = proUltraViewModel,
                        filterViewModel = filterViewModel,
                        onOpenMenu = { scope.launch { drawerState.open() } },
                        onOpenRatioPicker = { showRatioPicker = true },
                        onOpenFilterGallery = { navController.navigate(NavRoutes.FILTER_GALLERY) },
                        liquidGlass = liquidGlass
                    )

                    if (showRatioPicker) {
                        RatioPickerSheet(
                            selectedRatio = cameraState.selectedRatio,
                            onRatioSelected = { cameraViewModel.setSelectedRatio(it) },
                            onDismiss = { showRatioPicker = false },
                            liquidGlass = liquidGlass
                        )
                    }
                }
            }

            composable(NavRoutes.FILTER_GALLERY) {
                FilterGalleryScreen(
                    filterViewModel = filterViewModel,
                    onBack = { navController.popBackStack() },
                    onApplyFilterToCamera = { filter ->
                        cameraViewModel.setActiveFilter(filter)
                    },
                    liquidGlass = liquidGlass
                )
            }

            composable(NavRoutes.PRO_ULTRA_PRESETS) {
                ProUltraPresetsScreen(
                    proUltraViewModel = proUltraViewModel,
                    onBack = { navController.popBackStack() },
                    onApplyPreset = { preset ->
                        proUltraViewModel.loadPreset(preset)
                    },
                    liquidGlass = liquidGlass
                )
            }

            composable(NavRoutes.SETTINGS) {
                SettingsScreen(
                    settingsViewModel = settingsViewModel,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(NavRoutes.ABOUT) {
                AboutScreen(
                    onBack = { navController.popBackStack() },
                    liquidGlass = liquidGlass
                )
            }
        }
    }
}

@Composable
private fun DrawerItem(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    liquidGlass: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
        )
    }
}
