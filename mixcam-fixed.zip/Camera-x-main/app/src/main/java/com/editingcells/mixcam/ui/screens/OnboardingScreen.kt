package com.editingcells.mixcam.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.PermissionChecker
import com.editingcells.mixcam.ui.components.GlassButton
import com.editingcells.mixcam.ui.components.GlassPanel

@Composable
fun OnboardingScreen(
    onOnboardingComplete: () -> Unit,
    liquidGlass: Boolean = true
) {
    val context = LocalContext.current

    fun checkPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            permission
        ) == PermissionChecker.PERMISSION_GRANTED
    }

    var isCameraGranted by remember { mutableStateOf(checkPermission(Manifest.permission.CAMERA)) }

    val galleryPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.READ_MEDIA_IMAGES
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    var isGalleryGranted by remember { mutableStateOf(checkPermission(galleryPermission)) }

    val notificationPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        Manifest.permission.POST_NOTIFICATIONS
    } else null
    var isNotificationGranted by remember {
        mutableStateOf(notificationPermission == null || checkPermission(notificationPermission))
    }

    val permissionsToRequest = remember {
        buildList {
            add(Manifest.permission.CAMERA)
            add(galleryPermission)
            if (notificationPermission != null) {
                add(notificationPermission)
            }
        }.toTypedArray()
    }

    val multiplePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { resultMap ->
        isCameraGranted = resultMap[Manifest.permission.CAMERA] ?: checkPermission(Manifest.permission.CAMERA)
        isGalleryGranted = resultMap[galleryPermission] ?: checkPermission(galleryPermission)
        if (notificationPermission != null) {
            isNotificationGranted = resultMap[notificationPermission] ?: checkPermission(notificationPermission)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        GlassPanel(
            modifier = Modifier.fillMaxWidth(),
            liquidGlass = liquidGlass
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // App Logo Badge
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "MIXCAM Logo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Welcome to MIXCAM",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Pro Camera engine with real-time GPU filters, manual Camera2 ISO controls, and full gallery access.",
                    fontSize = 13.sp,
                    color = if (liquidGlass) Color.White.copy(alpha = 0.7f) else Color(0xFF64748B),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Camera Access
                RationaleRow(
                    icon = Icons.Default.CameraAlt,
                    title = "Camera Access",
                    subtitle = "Required for live viewfinder, photo capture, and manual focus controls.",
                    isGranted = isCameraGranted,
                    onRequest = {
                        multiplePermissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                    },
                    liquidGlass = liquidGlass
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Gallery Full Access
                RationaleRow(
                    icon = Icons.Default.PhotoLibrary,
                    title = "Gallery Full Access",
                    subtitle = "Allows saving high-res photos and picking photos directly from your media gallery.",
                    isGranted = isGalleryGranted,
                    onRequest = {
                        multiplePermissionLauncher.launch(arrayOf(galleryPermission))
                    },
                    liquidGlass = liquidGlass
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Notification Rationale
                if (notificationPermission != null) {
                    RationaleRow(
                        icon = Icons.Default.Notifications,
                        title = "Notifications & Alerts",
                        subtitle = "Receive instant alerts when high-res photos are saved to your gallery.",
                        isGranted = isNotificationGranted,
                        onRequest = {
                            multiplePermissionLauncher.launch(arrayOf(notificationPermission))
                        },
                        liquidGlass = liquidGlass
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                }

                // Master "Allow All Permissions" Button
                if (!isCameraGranted || !isGalleryGranted || !isNotificationGranted) {
                    GlassButton(
                        onClick = {
                            multiplePermissionLauncher.launch(permissionsToRequest)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        liquidGlass = liquidGlass
                    ) {
                        Text(
                            text = "ALLOW ALL PERMISSIONS",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Continue / Launch MIXCAM CTA
                GlassButton(
                    onClick = {
                        if (!isCameraGranted) {
                            multiplePermissionLauncher.launch(permissionsToRequest)
                        } else {
                            onOnboardingComplete()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    liquidGlass = liquidGlass
                ) {
                    Text(
                        text = if (isCameraGranted) "Launch MIXCAM Studio" else "Grant Permissions to Continue",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun RationaleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    isGranted: Boolean,
    onRequest: () -> Unit,
    liquidGlass: Boolean
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f)
            )
            if (isGranted) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Granted",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Granted",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = subtitle,
            fontSize = 12.sp,
            color = if (liquidGlass) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
        )

        if (!isGranted) {
            Spacer(modifier = Modifier.height(6.dp))
            GlassButton(
                onClick = onRequest,
                liquidGlass = liquidGlass,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Allow $title",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.White
                )
            }
        }
    }
}
