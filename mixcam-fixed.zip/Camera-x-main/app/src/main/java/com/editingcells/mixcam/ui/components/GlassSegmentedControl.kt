package com.editingcells.mixcam.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.domain.CameraMode
import com.editingcells.mixcam.ui.theme.SpringSpec

@Composable
fun GlassSegmentedControl(
    selectedMode: CameraMode,
    onModeSelected: (CameraMode) -> Unit,
    modifier: Modifier = Modifier,
    liquidGlass: Boolean = true
) {
    val modes = listOf(
        CameraMode.PHOTO to "Photo",
        CameraMode.PRO to "Pro",
        CameraMode.NIGHT to "Night",
        CameraMode.PRO_ULTRA to "Pro Ultra"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(32.dp))
            .then(
                if (liquidGlass) {
                    Modifier
                        .background(Color.Black.copy(alpha = 0.35f))
                        .border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(32.dp))
                } else {
                    Modifier
                        .background(Color(0xFFF1F5F9))
                        .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(32.dp))
                }
            )
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        modes.forEach { (mode, label) ->
            val isSelected = mode == selectedMode
            val alpha by animateFloatAsState(
                targetValue = if (isSelected) 1.0f else 0.6f,
                animationSpec = SpringSpec,
                label = "mode_alpha"
            )

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(24.dp))
                    .then(
                        if (isSelected) {
                            if (liquidGlass) {
                                Modifier
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.85f))
                                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                            } else {
                                Modifier.background(MaterialTheme.colorScheme.primary)
                            }
                        } else Modifier
                    )
                    .clickable { onModeSelected(mode) }
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = label,
                    fontSize = 13.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) {
                        Color.White
                    } else {
                        if (liquidGlass) Color.White.copy(alpha = alpha) else Color(0xFF64748B)
                    }
                )
            }
        }
    }
}
