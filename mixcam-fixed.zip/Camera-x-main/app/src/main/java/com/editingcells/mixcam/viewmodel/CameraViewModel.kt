package com.editingcells.mixcam.viewmodel

import android.media.MediaActionSound
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.editingcells.mixcam.data.preferences.UserPreferencesRepository
import com.editingcells.mixcam.domain.CameraController
import com.editingcells.mixcam.domain.CameraMode
import com.editingcells.mixcam.domain.FilterEngine
import com.editingcells.mixcam.domain.FilterSpec
import com.editingcells.mixcam.domain.FlashMode
import com.editingcells.mixcam.domain.GallerySaveRepository
import com.editingcells.mixcam.domain.MpOption
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class CameraUiState(
    val cameraMode: CameraMode = CameraMode.PHOTO,
    val isFrontFacing: Boolean = false,
    val flashMode: FlashMode = FlashMode.OFF,
    val isGridVisible: Boolean = false,
    val selectedMp: String = "12MP",
    val selectedRatio: String = "4:3",
    val supportedMps: List<MpOption> = emptyList(),
    val activeFilter: FilterSpec = FilterEngine.BUILT_IN_FILTERS.first(),
    val isCapturing: Boolean = false,
    val lastCapturedUri: Uri? = null,
    val errorMessage: String? = null
)

class CameraViewModel(
    val cameraController: CameraController,
    private val gallerySaveRepository: GallerySaveRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CameraUiState())
    val uiState: StateFlow<CameraUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            cameraController.initCameraProvider()
            val mps = cameraController.getSupportedMegapixels()
            _uiState.value = _uiState.value.copy(supportedMps = mps)

            // Observe user preferences
            combine(
                userPreferencesRepository.gridEnabled,
                userPreferencesRepository.selectedMp,
                userPreferencesRepository.selectedRatio
            ) { grid, mp, ratio ->
                _uiState.value = _uiState.value.copy(
                    isGridVisible = grid,
                    selectedMp = mp,
                    selectedRatio = ratio
                )
            }.collect {}
        }
    }

    fun setCameraMode(mode: CameraMode) {
        _uiState.value = _uiState.value.copy(cameraMode = mode)
    }

    fun toggleCameraFacing() {
        val nextFront = !_uiState.value.isFrontFacing
        _uiState.value = _uiState.value.copy(isFrontFacing = nextFront)
        viewModelScope.launch {
            val mps = cameraController.getSupportedMegapixels()
            _uiState.value = _uiState.value.copy(supportedMps = mps)
        }
    }

    fun cycleFlashMode() {
        val nextFlash = when (_uiState.value.flashMode) {
            FlashMode.OFF -> FlashMode.ON
            FlashMode.ON -> FlashMode.AUTO
            FlashMode.AUTO -> FlashMode.TORCH
            FlashMode.TORCH -> FlashMode.OFF
        }
        _uiState.value = _uiState.value.copy(flashMode = nextFlash)
        cameraController.applyFlashMode(nextFlash)
    }

    fun toggleGrid() {
        val nextGrid = !_uiState.value.isGridVisible
        _uiState.value = _uiState.value.copy(isGridVisible = nextGrid)
        viewModelScope.launch {
            userPreferencesRepository.setGridEnabled(nextGrid)
        }
    }

    fun setSelectedMp(mp: String) {
        _uiState.value = _uiState.value.copy(selectedMp = mp)
        viewModelScope.launch {
            userPreferencesRepository.setSelectedMp(mp)
        }
    }

    fun setSelectedRatio(ratio: String) {
        _uiState.value = _uiState.value.copy(selectedRatio = ratio)
        viewModelScope.launch {
            userPreferencesRepository.setSelectedRatio(ratio)
        }
    }

    fun setActiveFilter(filter: FilterSpec) {
        _uiState.value = _uiState.value.copy(activeFilter = filter)
    }

    fun capturePhoto() {
        if (_uiState.value.isCapturing) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isCapturing = true, errorMessage = null)
            try {
                try {
                    val soundIndex = userPreferencesRepository.shutterSoundIndex.first()
                    com.editingcells.mixcam.util.ShutterSoundManager.playShutterSound(soundIndex)
                } catch (e: Exception) {
                    // Ignore sound errors
                }
                val rawBitmap = cameraController.takePicture()
                val filteredBitmap = FilterEngine.applyFilterToBitmap(rawBitmap, _uiState.value.activeFilter)
                // BUGFIX: applyFilterToBitmap always returns a brand-new Bitmap and never
                // touched the raw capture, so the full-resolution raw bitmap (12–64MP)
                // was kept alive in memory with nothing referencing it — a leak on every
                // single photo. Recycle it now that the filtered copy exists.
                if (filteredBitmap !== rawBitmap && !rawBitmap.isRecycled) {
                    rawBitmap.recycle()
                }
                val notificationsEnabled = userPreferencesRepository.notificationsEnabled.first()

                val uri = gallerySaveRepository.saveBitmapToGallery(
                    bitmap = filteredBitmap,
                    triggerNotification = notificationsEnabled
                )
                if (!filteredBitmap.isRecycled) {
                    filteredBitmap.recycle()
                }

                _uiState.value = _uiState.value.copy(
                    isCapturing = false,
                    lastCapturedUri = uri
                )
                if (uri == null) {
                    // BUGFIX: previously a null Uri (insert/write failure) was treated as
                    // a silent success — isCapturing just went false with no feedback, so
                    // the user would think the photo saved when it actually didn't.
                    _uiState.value = _uiState.value.copy(
                        errorMessage = "Couldn't save photo to gallery. Please check storage permissions."
                    )
                }
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isCapturing = false,
                    errorMessage = "Capture failed: ${e.localizedMessage}"
                )
            }
        }
    }

    class Factory(
        private val cameraController: CameraController,
        private val gallerySaveRepository: GallerySaveRepository,
        private val userPreferencesRepository: UserPreferencesRepository
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CameraViewModel(cameraController, gallerySaveRepository, userPreferencesRepository) as T
        }
    }
}
