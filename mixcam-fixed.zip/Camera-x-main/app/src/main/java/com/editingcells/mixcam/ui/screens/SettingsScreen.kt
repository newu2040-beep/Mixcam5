package com.editingcells.mixcam.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.ui.components.GlassPanel
import com.editingcells.mixcam.ui.theme.AccentPresets
import com.editingcells.mixcam.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settingsViewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val liquidGlass by settingsViewModel.isLiquidGlassMode.collectAsState()
    val notificationsEnabled by settingsViewModel.notificationsEnabled.collectAsState()
    val activeAccentIndex by settingsViewModel.accentColorIndex.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "SETTINGS & SYSTEM",
                        fontWeight = FontWeight.Bold,
                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val themeName by settingsViewModel.themeModeName.collectAsState()

            // PROMINENT THEME MODE TOGGLE AT TOP
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                liquidGlass = liquidGlass
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "DESIGN ENGINE SYSTEM",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val themes = listOf(
                        "LIQUID_GLASS" to "Liquid Glass (Dark)",
                        "NORMAL_AESTHETIC" to "Minimal Aesthetic",
                        "CYBERPUNK" to "Cyberpunk Neon (Dark)",
                        "ROSE_GOLD" to "Rose Gold (Light)",
                        "MIDNIGHT_BLUE" to "Midnight Blue (Dark)",
                        "VINTAGE_SEPIA" to "Vintage Sepia (Warm)"
                    )
                    
                    themes.forEach { (mode, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { 
                                    settingsViewModel.setThemeName(mode)
                                    // Keep liquidGlass backward compatibility flag somewhat aligned
                                    if (mode == "NORMAL_AESTHETIC" || mode == "ROSE_GOLD" || mode == "VINTAGE_SEPIA") {
                                        settingsViewModel.toggleLiquidGlassMode(false)
                                    } else {
                                        settingsViewModel.toggleLiquidGlassMode(true)
                                    }
                                }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = themeName == mode,
                                onClick = { 
                                    settingsViewModel.setThemeName(mode)
                                    if (mode == "NORMAL_AESTHETIC" || mode == "ROSE_GOLD" || mode == "VINTAGE_SEPIA") {
                                        settingsViewModel.toggleLiquidGlassMode(false)
                                    } else {
                                        settingsViewModel.toggleLiquidGlassMode(true)
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = label,
                                fontSize = 14.sp,
                                fontWeight = if (themeName == mode) FontWeight.Bold else FontWeight.Normal,
                                color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // ACCENT COLOR PICKER
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                liquidGlass = liquidGlass
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "STUDIO ACCENT COLOR",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AccentPresets.forEachIndexed { index, color ->
                            val isSelected = index == activeAccentIndex
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(
                                        if (isSelected) 3.dp else 0.dp,
                                        Color.White,
                                        CircleShape
                                    )
                                    .clickable { settingsViewModel.setAccentIndex(index) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSelected) {
                                    Icon(
                                        Icons.Default.Check,
                                        contentDescription = "Selected Accent",
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // SHUTTER SOUND PICKER
            val shutterSoundIndex by settingsViewModel.shutterSoundIndex.collectAsState()
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                liquidGlass = liquidGlass
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "CAMERA SHUTTER SOUND",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val sounds = listOf(
                        0 to "Standard Click",
                        1 to "Soft Beep",
                        2 to "Aesthetic Chime",
                        3 to "Cyber Click"
                    )

                    sounds.forEach { (index, label) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { settingsViewModel.setShutterSoundIndex(index) }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            androidx.compose.material3.RadioButton(
                                selected = shutterSoundIndex == index,
                                onClick = { settingsViewModel.setShutterSoundIndex(index) },
                                colors = androidx.compose.material3.RadioButtonDefaults.colors(
                                    selectedColor = MaterialTheme.colorScheme.primary,
                                    unselectedColor = if (liquidGlass) Color.White.copy(alpha = 0.5f) else Color.Gray
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = label,
                                fontSize = 14.sp,
                                fontWeight = if (shutterSoundIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            // NOTIFICATION SETTINGS
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                liquidGlass = liquidGlass
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Photo Save Alerts",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Receive high-res capture confirmation alerts",
                            fontSize = 12.sp,
                            color = if (liquidGlass) Color.White.copy(alpha = 0.6f) else Color(0xFF64748B)
                        )
                    }

                    Switch(
                        checked = notificationsEnabled,
                        onCheckedChange = { settingsViewModel.toggleNotifications(it) }
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // FOOTER & CREDIT
            val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "MIXCAM v1.0.0",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Made with love by Rahul Shah",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (liquidGlass) Color.White.copy(alpha = 0.7f) else Color(0xFF64748B),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
                        .clickable { uriHandler.openUri("https://www.instagram.com/editingcells?igsh=YzVzdzkxdzRpNWNs") }
                )
            }
        }
    }
}
