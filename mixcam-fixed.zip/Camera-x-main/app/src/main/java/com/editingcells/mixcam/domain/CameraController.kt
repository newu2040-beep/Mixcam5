package com.editingcells.mixcam.domain

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.util.Log
import android.util.Size
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraControl
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.math.roundToInt

enum class CameraMode {
    PHOTO, PRO, NIGHT, PRO_ULTRA
}

enum class FlashMode {
    OFF, ON, AUTO, TORCH
}

data class MpOption(
    val label: String,
    val size: Size,
    val isSupported: Boolean
)

@OptIn(ExperimentalCamera2Interop::class)
class CameraController(private val context: Context) {

    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null

    var isFrontCamera: Boolean = false
        private set

    var currentFlashMode: FlashMode = FlashMode.OFF
        private set

    suspend fun initCameraProvider(): ProcessCameraProvider = suspendCancellableCoroutine { continuation ->
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                cameraProvider = provider
                continuation.resume(provider)
            } catch (e: Exception) {
                // BUGFIX: previously this swallowed the error and never resumed the
                // coroutine, which meant the ViewModel's init{} block would hang
                // forever and the whole camera screen would appear frozen with no
                // preview and no error shown. Now we fail loudly so the UI can react.
                Log.e("CameraController", "Error initializing camera provider", e)
                if (continuation.isActive) {
                    continuation.resumeWithException(e)
                }
            }
        }, ContextCompat.getMainExecutor(context))
    }

    /**
     * Structural (re)bind: camera facing, capture resolution, and whether we're in a
     * manual-controls mode (Pro / Pro Ultra) vs auto. This does an unbind + rebind and
     * will cause a brief preview flash, so it should ONLY be called when one of those
     * structural things actually changes.
     *
     * BUGFIX: previously every single ISO/shutter/WB/EV/focus slider tick in Pro/Pro
     * Ultra mode called this same function, which unbinds and rebinds the whole camera
     * use-case graph on every frame of a drag gesture — that's what caused the visible
     * preview stutter/flash and the "not smooth" feel. Live value pushes now go through
     * [updateManualControls] instead, which only patches the active capture request.
     */
    fun bindCamera(
        lifecycleOwner: LifecycleOwner,
        surfaceProvider: Preview.SurfaceProvider,
        isFront: Boolean = false,
        manualControlsEnabled: Boolean = false,
        targetResolution: Size? = null
    ) {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        isFrontCamera = isFront
        val selector = if (isFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA

        val previewBuilder = Preview.Builder()
        val imageCaptureBuilder = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)

        if (targetResolution != null) {
            imageCaptureBuilder.setTargetResolution(targetResolution)
        }

        // Put AE/AWB/AF into manual mode up front so subsequent slider drags can be
        // pushed as lightweight capture-request patches via updateManualControls().
        if (manualControlsEnabled) {
            val camera2PreviewExtender = Camera2Interop.Extender(previewBuilder)
            camera2PreviewExtender.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            camera2PreviewExtender.setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            camera2PreviewExtender.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
        }

        val preview = previewBuilder.build().also {
            it.setSurfaceProvider(surfaceProvider)
        }

        val capture = imageCaptureBuilder.build()
        imageCapture = capture

        try {
            val boundCamera = provider.bindToLifecycle(
                lifecycleOwner,
                selector,
                preview,
                capture
            )
            camera = boundCamera
            applyFlashMode(currentFlashMode)
        } catch (e: Exception) {
            Log.e("CameraController", "Use case binding failed", e)
        }
    }

    /**
     * Lightweight live update for Pro / Pro Ultra manual controls. Pushes a patched
     * capture request via Camera2CameraControl instead of unbinding/rebinding the whole
     * camera graph, so dragging ISO/shutter/WB/EV/focus sliders is smooth and doesn't
     * flash the preview. Call [bindCamera] with manualControlsEnabled = true first.
     */
    @OptIn(ExperimentalCamera2Interop::class)
    fun updateManualControls(
        iso: Int? = null,
        shutterSpeedNs: Long? = null,
        whiteBalanceKelvin: Int? = null,
        exposureComp: Int = 0,
        focusDistance: Float? = null
    ) {
        val boundCamera = camera ?: return
        val camera2Control = Camera2CameraControl.from(boundCamera.cameraControl)

        val optionsBuilder = CaptureRequestOptions.Builder()
            .setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            .setCaptureRequestOption(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            .setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)

        if (iso != null) {
            optionsBuilder.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
        }
        if (shutterSpeedNs != null) {
            optionsBuilder.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterSpeedNs)
        }
        if (whiteBalanceKelvin != null) {
            // BUGFIX: the old code set CONTROL_AWB_MODE_OFF but never actually supplied
            // manual color-correction gains, so the "white balance" slider did nothing —
            // it just froze auto white balance with no replacement value, producing
            // wrong/inconsistent color on every Pro / Pro Ultra shot. We now convert the
            // requested Kelvin temperature into RGB channel gains and apply them.
            val gains = kelvinToColorGains(whiteBalanceKelvin)
            optionsBuilder.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
            optionsBuilder.setCaptureRequestOption(CaptureRequest.COLOR_CORRECTION_GAINS, gains)
        }
        if (focusDistance != null) {
            optionsBuilder.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusDistance)
        }

        camera2Control.setCaptureRequestOptions(optionsBuilder.build())

        // Exposure compensation is a native CameraX control and doesn't need Camera2Interop.
        try {
            boundCamera.cameraControl.setExposureCompensationIndex(exposureComp)
        } catch (e: Exception) {
            // Some devices report a [0,0] EV range; ignore rather than crash the slider.
            Log.w("CameraController", "Exposure compensation not supported at value $exposureComp", e)
        }
    }

    /**
     * Approximate a black-body Kelvin temperature as Camera2 RGB channel gains
     * (Tanner Helland's algorithm, adapted to CameraX's RggbChannelVector gain scale).
     */
    private fun kelvinToColorGains(kelvin: Int): android.hardware.camera2.params.RggbChannelVector {
        val temp = kelvin.coerceIn(2000, 10000) / 100.0

        val red: Double
        val green: Double
        val blue: Double

        if (temp <= 66) {
            red = 255.0
            green = (99.4708025861 * Math.log(temp) - 161.1195681661).coerceIn(0.0, 255.0)
        } else {
            red = (329.698727446 * Math.pow(temp - 60, -0.1332047592)).coerceIn(0.0, 255.0)
            green = (288.1221695283 * Math.pow(temp - 60, -0.0755148492)).coerceIn(0.0, 255.0)
        }

        blue = when {
            temp >= 66 -> 255.0
            temp <= 19 -> 0.0
            else -> (138.5177312231 * Math.log(temp - 10) - 305.0447927307).coerceIn(0.0, 255.0)
        }

        // Normalize around green (the reference channel) so gains sit near 1.0.
        val gGain = 1.0f
        val rGain = (green / red.coerceAtLeast(1.0)).toFloat().coerceIn(0.3f, 4.0f)
        val bGain = (green / blue.coerceAtLeast(1.0)).toFloat().coerceIn(0.3f, 4.0f)

        return android.hardware.camera2.params.RggbChannelVector(rGain, gGain, gGain, bGain)
    }

    fun applyFlashMode(mode: FlashMode) {
        currentFlashMode = mode
        val capture = imageCapture
        val control = camera?.cameraControl ?: return

        when (mode) {
            FlashMode.OFF -> {
                capture?.flashMode = ImageCapture.FLASH_MODE_OFF
                control.enableTorch(false)
            }
            FlashMode.ON -> {
                capture?.flashMode = ImageCapture.FLASH_MODE_ON
                control.enableTorch(false)
            }
            FlashMode.AUTO -> {
                capture?.flashMode = ImageCapture.FLASH_MODE_AUTO
                control.enableTorch(false)
            }
            FlashMode.TORCH -> {
                capture?.flashMode = ImageCapture.FLASH_MODE_OFF
                control.enableTorch(true)
            }
        }
    }

    suspend fun takePicture(): Bitmap = suspendCancellableCoroutine { continuation ->
        val capture = imageCapture
        if (capture == null) {
            continuation.resumeWithException(IllegalStateException("Camera not bound"))
            return@suspendCancellableCoroutine
        }

        capture.takePicture(
            cameraExecutor,
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    val bitmap = imageProxyToBitmap(image)
                    image.close()
                    continuation.resume(bitmap)
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraController", "Photo capture failed", exception)
                    continuation.resumeWithException(exception)
                }
            }
        )
    }

    private fun imageProxyToBitmap(image: ImageProxy): Bitmap {
        val buffer = image.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)

        val rotationDegrees = image.imageInfo.rotationDegrees
        // BUGFIX: the matrix (and therefore the front-camera mirror flip) was only ever
        // applied when rotationDegrees != 0. On devices/orientations where CameraX reports
        // 0° rotation, front-camera selfies came out un-mirrored — i.e. flipped left/right
        // relative to what the user saw in the live preview and relative to every other
        // camera app. We now always mirror front-camera shots regardless of rotation.
        return if (rotationDegrees != 0 || isFrontCamera) {
            val matrix = Matrix()
            if (rotationDegrees != 0) {
                matrix.postRotate(rotationDegrees.toFloat())
            }
            if (isFrontCamera) {
                matrix.postScale(-1f, 1f) // Mirror front camera to match preview
            }
            val transformed = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
            // BUGFIX: createBitmap() returns a NEW bitmap here; the original `decoded`
            // bitmap was never recycled, leaking a full-resolution bitmap (often 12-64MP)
            // on every single photo. Over a shooting session this reliably leads to an
            // OutOfMemoryError. Recycle the intermediate once the transformed copy exists.
            if (transformed !== decoded) {
                decoded.recycle()
            }
            transformed
        } else {
            decoded
        }
    }

    fun getSupportedMegapixels(): List<MpOption> {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            ?: return listOf(MpOption("12MP", Size(4000, 3000), true))

        val options = mutableListOf<MpOption>()
        try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (isFrontCamera) facing == CameraCharacteristics.LENS_FACING_FRONT
                else facing == CameraCharacteristics.LENS_FACING_BACK
            } ?: cameraManager.cameraIdList.firstOrNull() ?: return listOf(MpOption("12MP", Size(4000, 3000), true))

            val characteristics = cameraManager.getCameraCharacteristics(cameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val outputSizes = map?.getOutputSizes(android.graphics.ImageFormat.JPEG) ?: emptyArray()

            var maxMp = 12
            outputSizes.forEach { size ->
                val mp = (size.width * size.height) / 1_000_000
                if (mp > maxMp) maxMp = mp
            }

            options.add(MpOption("12MP", Size(4000, 3000), true))
            options.add(MpOption("48MP", Size(8000, 6000), maxMp >= 40))
            options.add(MpOption("50MP", Size(8192, 6144), maxMp >= 45))
            options.add(MpOption("64MP", Size(9280, 6944), maxMp >= 60))

        } catch (e: Exception) {
            Log.e("CameraController", "Error querying Camera2 characteristics", e)
            options.add(MpOption("12MP", Size(4000, 3000), true))
        }

        return options
    }

    fun shutdown() {
        cameraExecutor.shutdown()
    }
}
