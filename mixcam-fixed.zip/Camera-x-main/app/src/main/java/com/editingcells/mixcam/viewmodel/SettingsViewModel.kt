package com.editingcells.mixcam.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.editingcells.mixcam.data.preferences.UserPreferencesRepository
import com.editingcells.mixcam.ui.theme.AccentPresets
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    val isLiquidGlassMode: StateFlow<Boolean> = userPreferencesRepository.isLiquidGlassMode
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    val themeModeName: StateFlow<String> = userPreferencesRepository.themeModeName
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = "LIQUID_GLASS"
        )

    val notificationsEnabled: StateFlow<Boolean> = userPreferencesRepository.notificationsEnabled
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = true
        )

    val accentColorIndex: StateFlow<Int> = userPreferencesRepository.accentColorIndex
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val shutterSoundIndex: StateFlow<Int> = userPreferencesRepository.shutterSoundIndex
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = 0
        )

    val onboardingCompleted: StateFlow<Boolean> = userPreferencesRepository.onboardingCompleted
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

    fun toggleLiquidGlassMode(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setThemeMode(if (enabled) "LIQUID_GLASS" else "NORMAL_AESTHETIC")
        }
    }

    fun setThemeName(name: String) {
        viewModelScope.launch {
            userPreferencesRepository.setThemeMode(name)
        }
    }

    fun toggleNotifications(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setNotificationsEnabled(enabled)
        }
    }

    fun setAccentIndex(index: Int) {
        viewModelScope.launch {
            userPreferencesRepository.setAccentColorIndex(index)
        }
    }

    fun setShutterSoundIndex(index: Int) {
        viewModelScope.launch {
            userPreferencesRepository.setShutterSoundIndex(index)
        }
    }

    fun completeOnboarding() {
        viewModelScope.launch {
            userPreferencesRepository.setOnboardingCompleted(true)
        }
    }

    class Factory(private val userPreferencesRepository: UserPreferencesRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SettingsViewModel(userPreferencesRepository) as T
        }
    }
}
