package com.editingcells.mixcam.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.editingcells.mixcam.data.local.FilterPreset
import com.editingcells.mixcam.data.local.FilterPresetDao
import com.editingcells.mixcam.domain.FilterEngine
import com.editingcells.mixcam.domain.FilterSpec
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FilterViewModel(
    private val filterPresetDao: FilterPresetDao
) : ViewModel() {

    private val _selectedFilter = MutableStateFlow<FilterSpec>(FilterEngine.BUILT_IN_FILTERS.first())
    val selectedFilter: StateFlow<FilterSpec> = _selectedFilter.asStateFlow()

    val customPresets: StateFlow<List<FilterPreset>> = filterPresetDao.getAllPresets()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun selectFilter(spec: FilterSpec) {
        _selectedFilter.value = spec
    }

    fun saveCustomPreset(
        name: String,
        brightness: Float,
        contrast: Float,
        saturation: Float,
        sepia: Float,
        vignette: Float,
        warmth: Float,
        tint: Float,
        sharpen: Float = 0f
    ) {
        viewModelScope.launch {
            val preset = FilterPreset(
                name = name,
                category = "Custom",
                brightness = brightness,
                contrast = contrast,
                saturation = saturation,
                sepia = sepia,
                vignette = vignette,
                warmth = warmth,
                tint = tint,
                sharpen = sharpen,
                isCustom = true
            )
            filterPresetDao.insertPreset(preset)
        }
    }

    fun deletePreset(preset: FilterPreset) {
        viewModelScope.launch {
            filterPresetDao.deletePreset(preset)
        }
    }

    class Factory(private val filterPresetDao: FilterPresetDao) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return FilterViewModel(filterPresetDao) as T
        }
    }
}
