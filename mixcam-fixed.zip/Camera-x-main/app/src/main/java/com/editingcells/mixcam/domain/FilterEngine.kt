package com.editingcells.mixcam.domain

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import kotlin.math.roundToInt

data class FilterSpec(
    val id: String,
    val name: String,
    val category: String,
    val brightness: Float = 0f,   // -1.0 to 1.0
    val contrast: Float = 1.0f,   // 0.5 to 2.0
    val saturation: Float = 1.0f, // 0.0 to 2.0
    val sepia: Float = 0f,        // 0.0 to 1.0
    val warmth: Float = 0f,       // -1.0 to 1.0
    val tint: Float = 0f,         // -1.0 to 1.0
    val vignette: Float = 0f,
    val sharpen: Float = 0f       // 0.0 to 1.0
)

object FilterEngine {

    val BUILT_IN_FILTERS = listOf(
        FilterSpec("original", "Original", "Classic"),
        FilterSpec("cyber_neon", "Cyber Neon", "Futuristic", brightness = 0.05f, contrast = 1.35f, saturation = 1.8f, tint = 0.4f),
        FilterSpec("teal_orange", "Teal & Orange", "Cinema", brightness = 0.02f, contrast = 1.25f, saturation = 1.3f, warmth = -0.2f),
        FilterSpec("vintage_warmth", "Vintage Gold", "Retro", brightness = 0.05f, contrast = 1.1f, saturation = 0.9f, sepia = 0.35f, warmth = 0.5f),
        FilterSpec("chrome_metallic", "Chrome", "Pro", brightness = 0.0f, contrast = 1.4f, saturation = 0.4f, warmth = -0.3f),
        FilterSpec("noir_bw", "Noir B&W", "Monochrome", brightness = -0.05f, contrast = 1.5f, saturation = 0.0f, vignette = 0.4f),
        FilterSpec("golden_sunset", "Golden Sunset", "Atmosphere", brightness = 0.08f, contrast = 1.15f, saturation = 1.4f, warmth = 0.7f),
        FilterSpec("dramatic_hdr", "Dramatic HDR", "Pro Ultra", brightness = 0.0f, contrast = 1.6f, saturation = 1.3f, warmth = 0.1f, vignette = 0.25f),
        FilterSpec("pastel_dream", "Pastel Dream", "Aesthetic", brightness = 0.1f, contrast = 0.9f, saturation = 0.8f, warmth = -0.1f, tint = 0.2f),
        FilterSpec("moody_forest", "Moody Forest", "Nature", brightness = -0.1f, contrast = 1.2f, saturation = 0.7f, tint = 0.3f, vignette = 0.3f),
        FilterSpec("polaroid", "Polaroid", "Retro", brightness = 0.05f, contrast = 0.95f, saturation = 0.85f, sepia = 0.2f, vignette = 0.2f),
        FilterSpec("neon_tokyo", "Tokyo Night", "Futuristic", brightness = 0.02f, contrast = 1.4f, saturation = 1.5f, warmth = -0.4f, tint = 0.5f),
        FilterSpec("desert_sand", "Desert Sand", "Atmosphere", brightness = 0.05f, contrast = 1.1f, saturation = 0.9f, warmth = 0.6f, sepia = 0.1f),
        FilterSpec("arctic_blue", "Arctic Blue", "Cool", brightness = 0.08f, contrast = 1.1f, saturation = 1.1f, warmth = -0.6f),
        FilterSpec("fade_matte", "Matte Fade", "Pro", brightness = 0.15f, contrast = 0.8f, saturation = 0.9f, warmth = 0.1f),
        FilterSpec("crimson_red", "Crimson", "Dramatic", brightness = -0.05f, contrast = 1.3f, saturation = 1.4f, warmth = 0.3f, tint = 0.4f),
        FilterSpec("soft_glow", "Soft Glow", "Aesthetic", brightness = 0.12f, contrast = 0.95f, saturation = 1.1f, warmth = 0.2f),
        FilterSpec("high_key", "High Key", "Pro", brightness = 0.2f, contrast = 1.1f, saturation = 0.9f),
        FilterSpec("low_key", "Low Key", "Pro", brightness = -0.2f, contrast = 1.3f, saturation = 1.1f, vignette = 0.5f),
        FilterSpec("sepia_strong", "Deep Sepia", "Retro", brightness = 0.0f, contrast = 1.2f, saturation = 0.7f, sepia = 0.8f, vignette = 0.3f),
        FilterSpec("emerald_city", "Emerald", "Nature", brightness = -0.02f, contrast = 1.2f, saturation = 1.2f, warmth = -0.1f, tint = 0.5f),
        FilterSpec("lavender_haze", "Lavender Haze", "Aesthetic", brightness = 0.05f, contrast = 1.0f, saturation = 0.9f, warmth = -0.3f, tint = 0.4f),
        FilterSpec("cinematic_teal", "Cinematic Teal", "Cinema", brightness = -0.05f, contrast = 1.3f, saturation = 1.1f, warmth = -0.4f, tint = -0.1f),
        FilterSpec("sunny_day", "Sunny Day", "Atmosphere", brightness = 0.1f, contrast = 1.1f, saturation = 1.3f, warmth = 0.4f),
        FilterSpec("dark_academia", "Dark Academia", "Aesthetic", brightness = -0.15f, contrast = 1.2f, saturation = 0.8f, warmth = 0.3f, sepia = 0.2f, vignette = 0.4f),
        FilterSpec("cyberpunk", "Cyberpunk", "Futuristic", brightness = 0.0f, contrast = 1.5f, saturation = 1.7f, warmth = -0.5f, tint = 0.6f),
        FilterSpec("rose_gold", "Rose Gold", "Aesthetic", brightness = 0.05f, contrast = 1.1f, saturation = 1.0f, warmth = 0.2f, tint = 0.3f)
    )

    fun createColorMatrix(spec: FilterSpec): ColorMatrix {
        val cm = ColorMatrix()

        // Saturation
        cm.setSaturation(spec.saturation)

        // Brightness & Contrast
        val contrastCm = ColorMatrix()
        val c = spec.contrast
        val b = spec.brightness * 255f
        val translate = (1f - c) * 128f + b
        contrastCm.set(floatArrayOf(
            c, 0f, 0f, 0f, translate,
            0f, c, 0f, 0f, translate,
            0f, 0f, c, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        ))
        cm.postConcat(contrastCm)

        // Sepia
        if (spec.sepia > 0f) {
            val s = spec.sepia
            val sepiaCm = ColorMatrix(floatArrayOf(
                1f - s + (s * 0.393f), s * 0.769f, s * 0.189f, 0f, 0f,
                s * 0.349f, 1f - s + (s * 0.686f), s * 0.168f, 0f, 0f,
                s * 0.272f, s * 0.534f, 1f - s + (s * 0.131f), 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
            cm.postConcat(sepiaCm)
        }

        // Temperature (Warmth) & Tint
        if (spec.warmth != 0f || spec.tint != 0f) {
            val rVal = 1f + (spec.warmth * 0.2f)
            val bVal = 1f - (spec.warmth * 0.2f)
            val gVal = 1f + (spec.tint * 0.2f)
            val warmCm = ColorMatrix(floatArrayOf(
                rVal, 0f, 0f, 0f, 0f,
                0f, gVal, 0f, 0f, 0f,
                0f, 0f, bVal, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            ))
            cm.postConcat(warmCm)
        }

        return cm
    }

    fun applyFilterToBitmap(inputBitmap: Bitmap, spec: FilterSpec): Bitmap {
        val outputBitmap = Bitmap.createBitmap(inputBitmap.width, inputBitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(outputBitmap)
        val paint = Paint().apply {
            colorFilter = ColorMatrixColorFilter(createColorMatrix(spec))
            isAntiAlias = true
            isFilterBitmap = true
        }
        canvas.drawBitmap(inputBitmap, 0f, 0f, paint)

        // Draw vignette if specified
        if (spec.vignette > 0f) {
            val vignettePaint = Paint().apply {
                isAntiAlias = true
                shader = android.graphics.RadialGradient(
                    inputBitmap.width / 2f,
                    inputBitmap.height / 2f,
                    Math.max(inputBitmap.width, inputBitmap.height) / 1.4f,
                    intArrayOf(android.graphics.Color.TRANSPARENT, android.graphics.Color.argb((spec.vignette * 200).toInt(), 0, 0, 0)),
                    floatArrayOf(0.5f, 1.0f),
                    android.graphics.Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, inputBitmap.width.toFloat(), inputBitmap.height.toFloat(), vignettePaint)
        }

        // BUGFIX: sharpen was a documented no-op — the slider/parameter existed end-to-end
        // (FilterSpec, presets, UI) but the code path below explicitly did nothing, so
        // every "Sharpen" adjustment silently had zero visual effect. RenderScript is
        // deprecated on modern Android, so this applies a real 3x3 unsharp-mask
        // convolution directly over the pixel array instead.
        val finalBitmap = if (spec.sharpen > 0f) {
            applySharpen(outputBitmap, spec.sharpen)
        } else {
            outputBitmap
        }

        return finalBitmap
    }

    private fun applySharpen(input: Bitmap, amount: Float): Bitmap {
        val width = input.width
        val height = input.height
        val src = IntArray(width * height)
        input.getPixels(src, 0, width, 0, 0, width, height)
        val dst = IntArray(width * height)

        val center = 1f + 4f * amount
        val edge = -amount

        for (y in 0 until height) {
            val yUp = if (y > 0) y - 1 else 0
            val yDown = if (y < height - 1) y + 1 else height - 1
            for (x in 0 until width) {
                val xLeft = if (x > 0) x - 1 else 0
                val xRight = if (x < width - 1) x + 1 else width - 1

                val pC = src[y * width + x]
                val pUp = src[yUp * width + x]
                val pDown = src[yDown * width + x]
                val pLeft = src[y * width + xLeft]
                val pRight = src[y * width + xRight]

                val r = convolveChannel(pC, pUp, pDown, pLeft, pRight, 16, center, edge)
                val g = convolveChannel(pC, pUp, pDown, pLeft, pRight, 8, center, edge)
                val b = convolveChannel(pC, pUp, pDown, pLeft, pRight, 0, center, edge)
                val a = (pC ushr 24) and 0xFF

                dst[y * width + x] = (a shl 24) or (r shl 16) or (g shl 8) or b
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(dst, 0, width, 0, 0, width, height)
        if (result !== input) {
            input.recycle()
        }
        return result
    }

    private fun convolveChannel(
        pC: Int, pUp: Int, pDown: Int, pLeft: Int, pRight: Int,
        shift: Int, center: Float, edge: Float
    ): Int {
        fun ch(p: Int) = (p ushr shift) and 0xFF
        val value = ch(pC) * center + edge * (ch(pUp) + ch(pDown) + ch(pLeft) + ch(pRight))
        return value.roundToInt().coerceIn(0, 255)
    }
}
