package com.editingcells.mixcam.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.ui.components.GlassPanel
import com.editingcells.mixcam.ui.components.GlassSlider
import com.editingcells.mixcam.viewmodel.ProUltraState

@Composable
fun ProModePanel(
    proState: ProUltraState,
    onIsoChange: (Int) -> Unit,
    onShutterChange: (Long) -> Unit,
    onWbChange: (Int) -> Unit,
    onEvChange: (Int) -> Unit,
    onFocusChange: (Float) -> Unit,
    liquidGlass: Boolean = true,
    wrapInPanel: Boolean = true,
    modifier: Modifier = Modifier
) {
    val content = @Composable {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(if (wrapInPanel) 16.dp else 0.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Text(
                    text = "MANUAL PRO CONTROLS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (liquidGlass) Color.White.copy(alpha = 0.9f) else Color.Black,
                    letterSpacing = 1.sp
                )
                
                com.editingcells.mixcam.ui.components.GlassButton(
                    onClick = {
                        // Reset to auto defaults
                        onIsoChange(400)
                        onShutterChange(10_000_000L) // 1/100s
                        onEvChange(0)
                    },
                    liquidGlass = liquidGlass
                ) {
                    Text(
                        text = "Auto Exposure",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            // ISO Slider (100 to 3200)
            GlassSlider(
                label = "ISO Sensitivity",
                value = proState.iso.toFloat(),
                onValueChange = { onIsoChange(it.toInt()) },
                valueRange = 100f..3200f,
                formattedValue = "ISO ${proState.iso}",
                liquidGlass = liquidGlass
            )

            // Shutter Speed Slider (1/8000s to 1s)
            val shutterFraction = (proState.shutterSpeedNs / 1_000_000_000f)
            val formattedShutter = if (shutterFraction >= 1f) "${shutterFraction.toInt()}s" else "1/${(1f / shutterFraction).toInt()}s"
            GlassSlider(
                label = "Shutter Speed",
                value = proState.shutterSpeedNs.toFloat(),
                onValueChange = { onShutterChange(it.toLong()) },
                valueRange = 125_000f..1_000_000_000f,
                formattedValue = formattedShutter,
                liquidGlass = liquidGlass
            )

            // White Balance Kelvin Slider (2000K to 10000K)
            GlassSlider(
                label = "White Balance",
                value = proState.whiteBalanceKelvin.toFloat(),
                onValueChange = { onWbChange(it.toInt()) },
                valueRange = 2000f..10000f,
                formattedValue = "${proState.whiteBalanceKelvin}K",
                liquidGlass = liquidGlass
            )

            // Exposure Compensation (-3 to +3 EV)
            GlassSlider(
                label = "Exposure Compensation",
                value = proState.exposureComp.toFloat(),
                onValueChange = { onEvChange(it.toInt()) },
                valueRange = -3f..3f,
                formattedValue = "${if (proState.exposureComp > 0) "+" else ""}${proState.exposureComp} EV",
                liquidGlass = liquidGlass
            )

            // Focus Distance (0.0 Macro to 1.0 Infinity)
            GlassSlider(
                label = "Manual Focus",
                value = proState.focusDistance,
                onValueChange = onFocusChange,
                valueRange = 0f..1f,
                formattedValue = if (proState.focusDistance < 0.1f) "∞ Infinity" else "${(proState.focusDistance * 100).toInt()}% Macro",
                liquidGlass = liquidGlass
            )
        }
    }

    if (wrapInPanel) {
        GlassPanel(
            modifier = modifier.fillMaxWidth(),
            liquidGlass = liquidGlass
        ) {
            content()
        }
    } else {
        content()
    }
}
