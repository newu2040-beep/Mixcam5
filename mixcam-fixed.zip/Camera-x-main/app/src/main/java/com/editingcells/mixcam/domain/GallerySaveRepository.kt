package com.editingcells.mixcam.domain

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.editingcells.mixcam.worker.CaptureNotificationWorker
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream

class GallerySaveRepository(private val context: Context) {

    suspend fun saveBitmapToGallery(
        bitmap: Bitmap,
        title: String = "MIXCAM_${System.currentTimeMillis()}",
        triggerNotification: Boolean = true
    ): Uri? = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$title.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/MIXCAM")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            ?: return@withContext null

        try {
            val outputStream: OutputStream? = resolver.openOutputStream(imageUri)
            if (outputStream != null) {
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, outputStream)
                outputStream.close()
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(imageUri, contentValues, null, null)
            }

            if (triggerNotification) {
                scheduleCaptureNotification(title)
            }

            return@withContext imageUri
        } catch (e: Exception) {
            e.printStackTrace()
            // BUGFIX: on write failure the MediaStore row created by insert() above was
            // never cleaned up, leaving a permanent broken/zero-byte "IS_PENDING" entry
            // in the user's gallery (shows as a grey broken thumbnail in DCIM/MIXCAM
            // forever). Delete the orphaned row so a failed capture doesn't pollute the
            // gallery.
            try {
                resolver.delete(imageUri, null, null)
            } catch (deleteError: Exception) {
                deleteError.printStackTrace()
            }
            return@withContext null
        }
    }

    private fun scheduleCaptureNotification(imageName: String) {
        try {
            val workRequest = OneTimeWorkRequestBuilder<CaptureNotificationWorker>()
                .setInputData(workDataOf("image_name" to imageName))
                .build()
            WorkManager.getInstance(context).enqueue(workRequest)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
