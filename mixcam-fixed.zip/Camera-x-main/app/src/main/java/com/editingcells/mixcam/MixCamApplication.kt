package com.editingcells.mixcam

import android.app.Application
import com.editingcells.mixcam.di.AppContainer

class MixCamApplication : Application() {

    lateinit var appContainer: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        appContainer = AppContainer(this)
    }
}
