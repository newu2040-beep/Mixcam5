package com.editingcells.mixcam

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.editingcells.mixcam.ui.navigation.MixCamNavGraph
import com.editingcells.mixcam.ui.theme.AccentPresets
import com.editingcells.mixcam.ui.theme.MixCamTheme
import com.editingcells.mixcam.viewmodel.CameraViewModel
import com.editingcells.mixcam.viewmodel.FilterViewModel
import com.editingcells.mixcam.viewmodel.ProUltraViewModel
import com.editingcells.mixcam.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val appContainer = (application as MixCamApplication).appContainer

        setContent {
            val settingsViewModel: SettingsViewModel = viewModel(
                factory = SettingsViewModel.Factory(appContainer.userPreferencesRepository)
            )

            val cameraViewModel: CameraViewModel = viewModel(
                factory = CameraViewModel.Factory(
                    cameraController = appContainer.cameraController,
                    gallerySaveRepository = appContainer.gallerySaveRepository,
                    userPreferencesRepository = appContainer.userPreferencesRepository
                )
            )

            val proUltraViewModel: ProUltraViewModel = viewModel(
                factory = ProUltraViewModel.Factory(appContainer.proUltraConfigRepository)
            )

            val filterViewModel: FilterViewModel = viewModel(
                factory = FilterViewModel.Factory(appContainer.database.filterPresetDao())
            )

            val liquidGlass by settingsViewModel.isLiquidGlassMode.collectAsState()
            val themeName by settingsViewModel.themeModeName.collectAsState()
            val accentIndex by settingsViewModel.accentColorIndex.collectAsState()
            val activeAccent = AccentPresets.getOrElse(accentIndex) { AccentPresets.first() }

            MixCamTheme(
                liquidGlassMode = liquidGlass,
                themeName = themeName,
                accentColor = activeAccent
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MixCamNavGraph(
                        cameraViewModel = cameraViewModel,
                        proUltraViewModel = proUltraViewModel,
                        filterViewModel = filterViewModel,
                        settingsViewModel = settingsViewModel
                    )
                }
            }
        }
    }
}
