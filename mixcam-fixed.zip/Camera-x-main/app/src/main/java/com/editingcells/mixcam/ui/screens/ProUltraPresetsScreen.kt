package com.editingcells.mixcam.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.data.local.ProUltraPreset
import com.editingcells.mixcam.ui.components.GlassButton
import com.editingcells.mixcam.ui.components.GlassCard
import com.editingcells.mixcam.viewmodel.ProUltraViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProUltraPresetsScreen(
    proUltraViewModel: ProUltraViewModel,
    onBack: () -> Unit,
    onApplyPreset: (ProUltraPreset) -> Unit,
    liquidGlass: Boolean = true
) {
    val savedPresets by proUltraViewModel.savedPresets.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "PRO ULTRA PRESETS",
                        fontWeight = FontWeight.Bold,
                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            if (savedPresets.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "No Saved Pro Ultra Presets",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Configure custom ISO, shutter speed, WB, and RGB gains in Pro Ultra mode and save them for instant studio recall.",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(savedPresets) { preset ->
                        GlassCard(
                            onClick = {
                                onApplyPreset(preset)
                                onBack()
                            },
                            liquidGlass = liquidGlass
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = preset.name,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                    Text(
                                        text = "ISO ${preset.iso} • ${preset.whiteBalanceKelvin}K • EV ${preset.exposureComp}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    GlassButton(
                                        onClick = {
                                            onApplyPreset(preset)
                                            onBack()
                                        },
                                        liquidGlass = liquidGlass
                                    ) {
                                        Text("Apply", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    }

                                    IconButton(onClick = { proUltraViewModel.deletePreset(preset) }) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete Preset",
                                            tint = Color.Red.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
