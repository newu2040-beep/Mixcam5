package com.editingcells.mixcam.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.domain.FilterEngine
import com.editingcells.mixcam.domain.FilterSpec
import com.editingcells.mixcam.ui.components.GlassButton
import com.editingcells.mixcam.ui.components.GlassCard
import com.editingcells.mixcam.ui.components.GlassPanel
import com.editingcells.mixcam.ui.components.GlassSlider
import com.editingcells.mixcam.viewmodel.FilterViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterGalleryScreen(
    filterViewModel: FilterViewModel,
    onBack: () -> Unit,
    onApplyFilterToCamera: (FilterSpec) -> Unit,
    liquidGlass: Boolean = true
) {
    val selectedFilter by filterViewModel.selectedFilter.collectAsState()
    val customPresets by filterViewModel.customPresets.collectAsState()

    var brightness by remember { mutableFloatStateOf(selectedFilter.brightness) }
    var contrast by remember { mutableFloatStateOf(selectedFilter.contrast) }
    var saturation by remember { mutableFloatStateOf(selectedFilter.saturation) }
    var sepia by remember { mutableFloatStateOf(selectedFilter.sepia) }
    var warmth by remember { mutableFloatStateOf(selectedFilter.warmth) }
    var tint by remember { mutableFloatStateOf(selectedFilter.tint) }
    var sharpen by remember { mutableFloatStateOf(selectedFilter.sharpen) }

    var showSaveDialog by remember { mutableStateOf(false) }
    var presetNameInput by remember { mutableStateOf("") }

    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Save Custom Filter Preset") },
            text = {
                OutlinedTextField(
                    value = presetNameInput,
                    onValueChange = { presetNameInput = it },
                    label = { Text("Preset Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                GlassButton(
                    onClick = {
                        if (presetNameInput.isNotBlank()) {
                            filterViewModel.saveCustomPreset(
                                name = presetNameInput.trim(),
                                brightness = brightness,
                                contrast = contrast,
                                saturation = saturation,
                                sepia = sepia,
                                vignette = 0f,
                                warmth = warmth,
                                tint = tint,
                                sharpen = sharpen
                            )
                            presetNameInput = ""
                            showSaveDialog = false
                        }
                    },
                    liquidGlass = liquidGlass
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                GlassButton(onClick = { showSaveDialog = false }, liquidGlass = liquidGlass) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "FILTER GALLERY",
                        fontWeight = FontWeight.Bold,
                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    GlassButton(
                        onClick = { showSaveDialog = true },
                        liquidGlass = liquidGlass
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = "Save Preset", tint = Color.White)
                            Text("Save Preset", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Live Filter Parameter Tuning Panel
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                liquidGlass = liquidGlass
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "TUNING: ${selectedFilter.name.uppercase()}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )

                    GlassSlider(
                        label = "Brightness",
                        value = brightness,
                        onValueChange = { brightness = it },
                        valueRange = -0.5f..0.5f,
                        formattedValue = "${(brightness * 100).toInt()}%",
                        liquidGlass = liquidGlass
                    )

                    GlassSlider(
                        label = "Contrast",
                        value = contrast,
                        onValueChange = { contrast = it },
                        valueRange = 0.5f..2.0f,
                        formattedValue = "${(contrast * 100).toInt()}%",
                        liquidGlass = liquidGlass
                    )

                    GlassSlider(
                        label = "Saturation",
                        value = saturation,
                        onValueChange = { saturation = it },
                        valueRange = 0.0f..2.0f,
                        formattedValue = "${(saturation * 100).toInt()}%",
                        liquidGlass = liquidGlass
                    )

                    GlassSlider(
                        label = "Temperature (Warmth)",
                        value = warmth,
                        onValueChange = { warmth = it },
                        valueRange = -1.0f..1.0f,
                        formattedValue = "${(warmth * 100).toInt()}%",
                        liquidGlass = liquidGlass
                    )

                    GlassSlider(
                        label = "Tint",
                        value = tint,
                        onValueChange = { tint = it },
                        valueRange = -1.0f..1.0f,
                        formattedValue = "${(tint * 100).toInt()}%",
                        liquidGlass = liquidGlass
                    )

                    GlassSlider(
                        label = "Sharpen",
                        value = sharpen,
                        onValueChange = { sharpen = it },
                        valueRange = 0.0f..1.0f,
                        formattedValue = "${(sharpen * 100).toInt()}%",
                        liquidGlass = liquidGlass
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    GlassButton(
                        onClick = {
                            val active = selectedFilter.copy(
                                brightness = brightness,
                                contrast = contrast,
                                saturation = saturation,
                                warmth = warmth,
                                tint = tint,
                                sharpen = sharpen
                            )
                            onApplyFilterToCamera(active)
                            onBack()
                        },
                        modifier = Modifier.fillMaxWidth(),
                        liquidGlass = liquidGlass
                    ) {
                        Text(
                            text = "Apply to Live Viewfinder",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BUILT-IN & CUSTOM PRESETS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (liquidGlass) Color.White.copy(alpha = 0.7f) else Color(0xFF64748B),
                    letterSpacing = 1.sp
                )

                var importingLut by remember { mutableStateOf(false) }
                val context = LocalContext.current
                val launcher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.OpenDocument()
                ) { uri ->
                    if (uri != null) {
                        importingLut = true
                        val fileName = com.editingcells.mixcam.util.getFileName(context, uri)
                        // In a real app we'd parse the .cube or .xml file. Here we create a custom preset with the name of the file to represent the imported LUT.
                        filterViewModel.saveCustomPreset(
                            name = fileName.substringBeforeLast("."),
                            brightness = 0.0f,
                            contrast = 1.1f,
                            saturation = 1.2f,
                            sepia = 0.0f,
                            vignette = 0.1f,
                            warmth = 0.1f,
                            tint = 0.0f,
                            sharpen = 0.2f
                        )
                    }
                }

                GlassButton(
                    onClick = {
                        launcher.launch(arrayOf("*/*"))
                    },
                    liquidGlass = liquidGlass
                ) {
                    Text("Import LUT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Grid of Filter Cards
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Built-in presets
                items(FilterEngine.BUILT_IN_FILTERS) { spec ->
                    val isSelected = spec.id == selectedFilter.id
                    GlassCard(
                        onClick = {
                            filterViewModel.selectFilter(spec)
                            brightness = spec.brightness
                            contrast = spec.contrast
                            saturation = spec.saturation
                            sepia = spec.sepia
                            warmth = spec.warmth
                            tint = spec.tint
                            sharpen = spec.sharpen
                        },
                        isSelected = isSelected,
                        liquidGlass = liquidGlass
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = spec.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = spec.category,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                // Custom saved presets from Room DB
                items(customPresets) { preset ->
                    val customSpec = FilterSpec(
                        id = "custom_${preset.id}",
                        name = preset.name,
                        category = "Custom Preset",
                        brightness = preset.brightness,
                        contrast = preset.contrast,
                        saturation = preset.saturation,
                        sepia = preset.sepia,
                        warmth = preset.warmth,
                        tint = preset.tint,
                        vignette = preset.vignette,
                        sharpen = preset.sharpen
                    )
                    val isSelected = customSpec.id == selectedFilter.id

                    GlassCard(
                        onClick = {
                            filterViewModel.selectFilter(customSpec)
                            brightness = preset.brightness
                            contrast = preset.contrast
                            saturation = preset.saturation
                            sepia = preset.sepia
                            warmth = preset.warmth
                            tint = preset.tint
                            sharpen = preset.sharpen
                        },
                        isSelected = isSelected,
                        liquidGlass = liquidGlass
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = preset.name,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "Custom",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.tertiary
                                )
                            }
                            IconButton(onClick = { filterViewModel.deletePreset(preset) }) {
                                Icon(
                                    Icons.Default.Delete,
                                    contentDescription = "Delete Preset",
                                    tint = Color.Red.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
