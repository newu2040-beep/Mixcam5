package com.editingcells.mixcam.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.editingcells.mixcam.ui.components.GlassPanel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onBack: () -> Unit,
    liquidGlass: Boolean = true
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "ABOUT MIXCAM",
                        fontWeight = FontWeight.Bold,
                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = if (liquidGlass) Color(0xFF0B0F19) else MaterialTheme.colorScheme.background
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            GlassPanel(
                modifier = Modifier.fillMaxWidth(),
                liquidGlass = liquidGlass
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = "MIXCAM Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "MIXCAM Pro Camera",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = "Version 1.0.0 Pro Ultra Edition",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "A modern camera system featuring real-time GPU filter preview, Camera2Interop manual ISO/shutter controls, custom tone curves, multi-frame night stacking, and the Liquid Glass dual design layer.",
                        fontSize = 13.sp,
                        color = if (liquidGlass) Color.White.copy(alpha = 0.7f) else Color(0xFF64748B),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                    Text(
                        text = "Made with love by Rahul Shah",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (liquidGlass) Color.White else MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.clickable { uriHandler.openUri("https://www.instagram.com/editingcells?igsh=YzVzdzkxdzRpNWNs") }
                    )
                }
            }
        }
    }
}
