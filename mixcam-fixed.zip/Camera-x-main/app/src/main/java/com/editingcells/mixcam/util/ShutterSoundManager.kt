package com.editingcells.mixcam.util

import android.media.AudioManager
import android.media.MediaActionSound
import android.media.ToneGenerator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object ShutterSoundManager {
    private val standardSound = MediaActionSound()

    fun playShutterSound(index: Int) {
        when (index) {
            0 -> standardSound.play(MediaActionSound.SHUTTER_CLICK)
            1 -> { // Soft beep
                val toneG = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                toneG.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
                CoroutineScope(Dispatchers.Default).launch {
                    delay(150)
                    toneG.release()
                }
            }
            2 -> { // Aesthetic chime
                val toneG = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                toneG.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 150)
                CoroutineScope(Dispatchers.Default).launch {
                    delay(200)
                    toneG.release()
                }
            }
            3 -> { // Cyber click
                val toneG = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
                toneG.startTone(ToneGenerator.TONE_DTMF_0, 50)
                CoroutineScope(Dispatchers.Default).launch {
                    delay(80)
                    toneG.startTone(ToneGenerator.TONE_DTMF_8, 50)
                    delay(80)
                    toneG.release()
                }
            }
            else -> standardSound.play(MediaActionSound.SHUTTER_CLICK)
        }
    }
}
