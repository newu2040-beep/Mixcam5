# SETUP & BUILD GUIDE — MIXCAM

## Overview
**MIXCAM** is a professional Android camera application built using **100% Kotlin**, **Jetpack Compose**, and **Material 3** overlaid with a custom **Liquid Glass** design system.

Key features include:
- **Liquid Glass & Normal Aesthetic Dual Theme System**: Layered translucent blur, specular light sheen, refractive borders, and fluid spring animations (switchable instantly in Settings).
- **Camera2Interop Manual Pro Controls**: Manual ISO (100–3200), Shutter Speed (1/8000s to 1s), White Balance Kelvin (2000K–10000K), Exposure Compensation (-3 to +3 EV), and Focus Distance (0 to 1).
- **Pro Ultra Advanced Mode**: Custom tone curve control, per-channel RGB color gain tuner, custom multi-frame EV bracketing, RAW capture toggle, and saved Pro Ultra studio presets stored in Room DB.
- **Night Mode Stacking**: Exposure duration control (2s, 5s, 10s) with multi-frame noise reduction.
- **Real-time GPU Filter Engine**: Built-in + custom filter presets (Cyber Neon, Teal & Orange, Vintage Gold, Noir B&W, Chrome, Golden Sunset, Dramatic HDR).
- **Dynamic Megapixel Querying**: Queries hardware `StreamConfigurationMap` for 12MP, 48MP, 50MP, and 64MP modes, hiding unsupported choices dynamically.
- **MediaStore Gallery Auto-Save**: Saves captured photos to `DCIM/MIXCAM` with background notification alerts via WorkManager.

---

## Technical Specs
- **Namespace / Package**: `com.editingcells.mixcam`
- **Application ID**: `com.editingcells.mixcam`
- **Compile SDK**: 35
- **Target SDK**: 35
- **Min SDK**: 26
- **JDK Version**: Java 17
- **Gradle Version**: 9.3.1 (AGP 9.1.1)

---

## RenderEffect Blur & API Level Fallback Notes
- **API 31+ (Android 12+)**: Uses native hardware-accelerated `RenderEffect.createBlurEffect()` for true frosted real-time glass blur on panels, buttons, cards, and bottom sheets.
- **API 26–30 (Android 8.0 – 11)**: Dynamically falls back to a high-contrast semi-transparent dark scrim overlay (`Color.White.copy(alpha = 0.15f)` / `Color.Black.copy(alpha = 0.35f)`) with specular gradient borders and spring physics, ensuring 100% smooth frame rate performance without UI degradation or missing controls.

---

## Local Build & Execution Steps

### 1. Prerequisites
- Android Studio Ladybug / Koala or CLI with Android SDK 35 installed.
- JDK 17 configured as JAVA_HOME.

### 2. Build Debug APK
```bash
# Build the debug APK via Gradle wrapper
gradle assembleDebug
```
The generated APK will be available at:
`app/build/outputs/apk/debug/app-debug.apk`

### 3. Run Robolectric & Unit Tests
```bash
gradle :app:testDebugUnitTest
```

---

## GitHub Actions CI Workflow (`.github/workflows/build-apk.yml`)
The repository includes an automated GitHub Actions CI workflow configured as follows:
- **Triggers**: Pushes & Pull Requests to `main`/`master` branches, plus manual `workflow_dispatch`.
- **Environment**: `ubuntu-latest`, **Java 17 (Temurin)**, **Gradle 9.3.1**.
- **Outputs**: Compiles `gradle assembleDebug` and uploads the resulting `mixcam-debug-apk` artifact.

---

## Author & Credits
- **App Name**: MIXCAM
- **Credit**: Made with love by Rahul Shah
